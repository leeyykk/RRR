package rrr;

import java.awt.Point;
import java.awt.Rectangle;

public class RRRSelectionBox extends Rectangle {
    // fields
    private Point mAnchorPt = null;
    
    // constructor
    public RRRSelectionBox(Point pt) {
        super(pt);
        this.mAnchorPt = pt;
    }
    
    // methods
    public void update(Point pt) {
        this.setRect(this.mAnchorPt.x, this.mAnchorPt.y, 0, 0);
        this.add(pt);
    }
}
