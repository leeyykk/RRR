package rrr;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.UIManager;
import rrr.cmd.RRRCmdToChangeModeTo;
import rrr.scenario.RRRReviewScenario;
import rrr.scenario.RRRRecordScenario;
import rrr.scenario.RRRReviseScenario;
import x.XCmdToChangeScene;

public class RRRHeader extends JPanel {
    // constants    
    private static final Color FONT_COLOR = new Color(255, 255, 255);
    private static final Font FONT_INFO = 
        new Font("SansSerif", Font.PLAIN, 18);
    
    private static final int INFO_TOP_ALIGNMENT_X = 20;
    private static final int INFO_TOP_ALIGNMENT_Y = 25;
    
    // fields
    private RRR mRRR = null;
    private JButton mPrevModeButton = null;
    
    private JPanel mEmptyPanel = null;
    private JPanel mModePanel = null;
    private JPanel mColorPanel = null;
    
    // constructor
    public RRRHeader(RRR rrr) {
        this.mRRR = rrr;
        setBackground(Color.LIGHT_GRAY);
        setLayout(new BorderLayout());
        
        this.mEmptyPanel = new JPanel();
        this.mEmptyPanel.setOpaque(false);
        this.mEmptyPanel.setPreferredSize(new Dimension(100, 100));
        
        this.mModePanel = new JPanel();
        this.mModePanel.setLayout(new FlowLayout());
        this.mModePanel.setOpaque(false);
        this.drawModeButtons();
        
        this.mColorPanel = new JPanel();
        this.mColorPanel.setLayout(new FlowLayout());
        this.mColorPanel.setOpaque(false);
        this.mColorPanel.setPreferredSize(new Dimension(100, 100));
        this.drawColorButtons();
        
        add(mEmptyPanel, BorderLayout.WEST);
        add(mModePanel, BorderLayout.CENTER);
        add(mColorPanel, BorderLayout.EAST);
    }
    
    // methods
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); 
        Graphics2D g2 = (Graphics2D) g;
        
        // turn on anti-aliasing
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
            RenderingHints.VALUE_ANTIALIAS_ON);
        
        this.drawInfo(g2);
    }
    
    private void drawInfo(Graphics2D g2) {
        RRRScene curScene = (RRRScene)this.mRRR.getScenarioMgr().getCurScene();
        String str = this.mRRR.getMode().name() + ": " + 
            curScene.getClass().getSimpleName();
        g2.setColor(RRRHeader.FONT_COLOR);
        g2.setFont(RRRHeader.FONT_INFO);
        g2.drawString(str, RRRHeader.INFO_TOP_ALIGNMENT_X, 
            RRRHeader.INFO_TOP_ALIGNMENT_Y);
    }
    
    private void drawModeButtons() {
        JButton reviewModeButton = new JButton("Review");        
        JButton recordModeButton = new JButton("Record");
        JButton reviseModeButton = new JButton("Revise");
        
        reviewModeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                RRRCmdToChangeModeTo.execute(mRRR, RRR.Mode.REVIEW);
                
                XCmdToChangeScene.execute(mRRR, 
                    RRRReviewScenario.ReviewReadyScene.getSingleton(),
                    null);

                reviewModeButton.setBorder(BorderFactory.createBevelBorder(1));
                reviewModeButton.setPreferredSize(new Dimension(75,22));
                
                if(mPrevModeButton != null) {
                    mPrevModeButton.setBorder(UIManager
                        .getBorder("Button.border"));
                    mPrevModeButton.setPreferredSize(
                        UIManager.getDimension("Button.size"));
                }
                mPrevModeButton = reviewModeButton;
                
                mRRR.repaint();
            }
        });
        
        recordModeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                RRRCmdToChangeModeTo.execute(mRRR, RRR.Mode.RECORD);
                
                XCmdToChangeScene.execute(mRRR, 
                    RRRRecordScenario.RecordReadyScene.getSingleton(),
                    null);
                
                recordModeButton.setBorder(BorderFactory.createBevelBorder(1));
                recordModeButton.setPreferredSize(new Dimension(75,22));
                
                if(mPrevModeButton != null) {
                    mPrevModeButton.setBorder(UIManager
                        .getBorder("Button.border"));
                    mPrevModeButton.setPreferredSize(
                        UIManager.getDimension("Button.size"));
                }
                mPrevModeButton = recordModeButton;
                
                mRRR.repaint();
            }
        });
        
        reviseModeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {       
                RRRCmdToChangeModeTo.execute(mRRR, RRR.Mode.REVISE);
                
                XCmdToChangeScene.execute(mRRR, 
                    RRRReviseScenario.ReviseReadyScene.getSingleton(), 
                    null);
                
                reviseModeButton.setBorder(BorderFactory.createBevelBorder(1));
                reviseModeButton.setPreferredSize(new Dimension(75,22));
                
                if(mPrevModeButton != null) {
                    mPrevModeButton.setBorder(UIManager
                        .getBorder("Button.border"));
                    mPrevModeButton.setPreferredSize(
                        UIManager.getDimension("Button.size"));
                }
                mPrevModeButton = reviseModeButton;
                
                mRRR.repaint();
            }
        });
        
        this.mModePanel.add(reviewModeButton);
        this.mModePanel.add(recordModeButton);
        this.mModePanel.add(reviseModeButton);
        
        reviewModeButton.setFocusable(false);
        recordModeButton.setFocusable(false);
        reviseModeButton.setFocusable(false); 
    }

    private void drawColorButtons() {
        JButton blackButton = new JButton();        
        JButton redButton = new JButton();
        JButton blueButton = new JButton();
        
        blackButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 10));
        redButton.setBorder(BorderFactory.createLineBorder(Color.RED, 10));
        blueButton.setBorder(BorderFactory.createLineBorder(Color.BLUE, 10));
        
        blackButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mRRR.getCanvas2D().setCurColorForPtCurve(Color.BLACK);
                
                blackButton.setBorder(
                    BorderFactory.createLineBorder(Color.BLACK, 10));
                redButton.setBorder(
                    BorderFactory.createLineBorder(Color.RED, 5));
                blueButton.setBorder(
                    BorderFactory.createLineBorder(Color.BLUE, 5));
                
                mRRR.repaint();
            }
        });
        
        redButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mRRR.getCanvas2D().setCurColorForPtCurve(Color.RED);
                
                blackButton.setBorder(
                    BorderFactory.createLineBorder(Color.BLACK, 5));
                redButton.setBorder(
                    BorderFactory.createLineBorder(Color.RED, 10));
                blueButton.setBorder(
                    BorderFactory.createLineBorder(Color.BLUE, 5));
                
                mRRR.repaint();
            }
        });
        
        blueButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mRRR.getCanvas2D().setCurColorForPtCurve(Color.BLUE);
                
                blackButton.setBorder(
                    BorderFactory.createLineBorder(Color.BLACK, 5));
                redButton.setBorder(
                    BorderFactory.createLineBorder(Color.RED, 5));
                blueButton.setBorder(
                    BorderFactory.createLineBorder(Color.BLUE, 10));
                
                mRRR.repaint();
            }
        });
        
        this.mColorPanel.add(blackButton);
        this.mColorPanel.add(redButton);
        this.mColorPanel.add(blueButton);
        
        blackButton.setFocusable(false);
        redButton.setFocusable(false);
        blueButton.setFocusable(false); 
        
        blackButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 10));
        redButton.setBorder(BorderFactory.createLineBorder(Color.RED, 5));
        blueButton.setBorder(BorderFactory.createLineBorder(Color.BLUE, 5));
    }
}