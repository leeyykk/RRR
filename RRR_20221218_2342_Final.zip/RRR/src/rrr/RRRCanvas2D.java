package rrr;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.geom.Line2D;
import java.awt.geom.Path2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JPanel;
import rrr.scenario.RRRDrawScenario;

public class RRRCanvas2D extends JPanel {
    // constants
    private static final String FILE_PATH = "src/images/인소디.png";

    private static final Color COLOR_PT_CURVE_DEFAULT = Color.BLACK;
    private static final Color COLOR_SELECTED_PT_CURVES = Color.ORANGE;
    public static final Color COLOR_SELECTION_BOX = new Color(255, 0, 0, 64);
    public static final Color COLOR_CROSS_HAIR = new Color(255, 0, 0, 64);
    public static final Color COLOR_NODE = Color.WHITE;
    public static final Color COLOR_EDGE = Color.BLACK;
    public static final Color COLOR_EDGE_HIGHLIGHT = Color.RED;
    public static final Color COLOR_SELECTED_OBJECT = new Color(255, 0, 0, 64);
    public static final Color COLOR_SHEET_INFO = new Color(255, 255, 255);
    
    private static final Stroke STROKE_CUR_PT_CURVE_DEFAULT = new BasicStroke(
        3f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
    public static final Stroke STROKE_SELECTION_BOX = new BasicStroke(5f);
    public static final Stroke STROKE_CROSS_HAIR = new BasicStroke(5f);
    public static final Stroke STROKE_NODE = new BasicStroke(5f);
    public static final Stroke STROKE_EDGE = new BasicStroke(5f);

    private static final Color COLOR_QUESTION_SHEET = new Color(245, 218, 223);
    private static final Color COLOR_REVISE_SHEET = new Color(173, 216, 230);
    public static final Stroke STROKE_SHEET = new BasicStroke(0f);
    public static final Stroke STROKE_GUIDELINES = new BasicStroke(3f);
    
    private static final Font FONT_INFO = 
        new Font("Monospaced", Font.PLAIN, 24);
    
    public static final double ZOOM_ROTATE_CROSS_HAIR_RADIUS = 30.0;
    public static final float STROKE_WIDTH_INCREMENT = 1f;
    public static final float STROKE_MIN_WIDTH = 1f;
    
    // fields
    private RRR mRRR = null;
    
    private BufferedImage mImage = null; 
    public BufferedImage getImage() {
        return this.mImage;
    }
    
    private Color mCurColorForPtCurve = null;
    public Color getCurColorForPtCurve() {
        return this.mCurColorForPtCurve;
    }
    public void setCurColorForPtCurve(Color c) {
        this.mCurColorForPtCurve = c;
    }
    private Stroke mCurStrokeForPtCurve = null;
    public Stroke getCurStrokeForPtCurve() {
        return this.mCurStrokeForPtCurve;
    }
    
    // constructor
    public RRRCanvas2D(RRR rrr) {
        this.mRRR = rrr;
        
        File imageFile = new File(FILE_PATH);
        try {
            this.mImage = ImageIO.read(imageFile);
            System.out.println("File loaded successfully");
        } catch(IOException e) {
            System.out.println(e);
        }
        
        this.mCurColorForPtCurve = RRRCanvas2D.COLOR_PT_CURVE_DEFAULT;
        this.mCurStrokeForPtCurve = RRRCanvas2D.STROKE_CUR_PT_CURVE_DEFAULT;
    }

    // methods
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); 
        Graphics2D g2 = (Graphics2D) g;
        
        // turn on anti-aliasing
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, 
            RenderingHints.VALUE_ANTIALIAS_ON);
        
        // world objects
        // transform the coordinate system from screen to world
        // note: the transformation of a coordinate system is 
        // the reversed process of the transformation of a geometric object
        g2.transform(this.mRRR.getXform().getCurXformFromWorldToScreen());
        
        // render common world objects
        this.drawImage(g2);
        this.drawSheet(g2);
        this.drawSheetInfo(g2);
        this.drawGuidelines(g2);
        if(this.mRRR.getMode() == RRR.Mode.REVISE && 
            this.mRRR.getPtCurveMgr().getRecordPtCurvesVisibility()) {
            
            ArrayList<RRRPtCurve> ptCurves = this.mRRR.getPtCurveMgr().getRecordPtCurves();
            this.drawPtCurves(g2, ptCurves);
        }
        if(this.mRRR.getMode() != RRR.Mode.EXTRACTEDGE && this.mRRR.getMode() != RRR.Mode.EXTRACTNODE) {
            this.drawPtCurves(g2);
        }
        this.drawSelectedPtCurves(g2);
        this.drawCurPtCurve(g2);
                
        // render the current scene's world objects
        RRRScene curScene = (RRRScene) this.mRRR.getScenarioMgr().getCurScene();
        curScene.renderWorldObjects(g2);

        // screen objects
        // transform the coordinate system from world to screen
        g2.transform(this.mRRR.getXform().getCurXformFromScreenToWorld());
        
        // render common screen objects
        
        // render the current scene's screen objects
        curScene.renderScreenObjects(g2);
    }

    private void drawImage(Graphics2D g2) {
        g2.drawImage(this.mImage, 0, 0, null);
    }
    
    private void drawPtCurves(Graphics2D g2) {
        ArrayList<RRRPtCurve> ptCurves = this.mRRR.getPtCurveMgr().getPtCurves();
        this.drawPtCurves(g2, ptCurves);
    }
    
    private void drawPtCurves(Graphics2D g2, ArrayList<RRRPtCurve> ptCurves) {
        if(ptCurves != null) {
            for(RRRPtCurve ptCurve : ptCurves) {
                this.drawPtCurve(g2, ptCurve, ptCurve.getColor(), 
                    ptCurve.getStroke());
            }
        }
    }

    private void drawCurPtCurve(Graphics2D g2) {
        RRRScene curScene = (RRRScene) this.mRRR.getScenarioMgr().getCurScene();
        if(curScene.getScenario() == RRRDrawScenario.getSingleton()) {
            RRRPtCurve ptCurve = this.mRRR.getPtCurveMgr().getCurPtCurve();
            if(ptCurve != null) {
                this.drawPtCurve(g2, ptCurve, this.mCurColorForPtCurve, 
                    ptCurve.getStroke());
            }
        }
    }

    private void drawPtCurve(
        Graphics2D g2, RRRPtCurve ptCurve, Color c, Stroke s) {

        Path2D.Double path = new Path2D.Double();
        ArrayList<Point2D.Double> pts = ptCurve.getPts();
        if(pts.size() < 2) {
            return;
        }
        
        Point2D.Double pt0 = pts.get(0);
        path.moveTo(pt0.x, pt0.y);
        for(int i = 1; i < pts.size(); i++) {
            Point2D.Double pt = pts.get(i);
            path.lineTo(pt.x, pt.y);
        }
        
        g2.setColor(c);
        g2.setStroke(s);
        g2.draw(path);
    }

    private void drawSelectedPtCurves(Graphics2D g2) {
        for(RRRPtCurve ptCurve : this.mRRR.getPtCurveMgr().getSelectedPtCurves()) {
            this.drawPtCurve(g2, ptCurve, RRRCanvas2D.COLOR_SELECTED_PT_CURVES, 
                ptCurve.getStroke());
        }
    }
    
    private void drawSheet(Graphics2D g2) {
        int width = RRR.APP_WIDTH;
        int height = RRR.APP_HEIGHT;
               
        ArrayList<Rectangle2D> sheets = new ArrayList<Rectangle2D>();
        Rectangle2D sheet = 
            new Rectangle2D.Double(0, 0, width, height);
        
        if(this.mRRR.getMode() == RRR.Mode.QUESTION) {
            g2.setColor(RRRCanvas2D.COLOR_QUESTION_SHEET);
            g2.fill(sheet);
            g2.setStroke(RRRCanvas2D.STROKE_SHEET);
            sheets.add(sheet); 
        } else if(this.mRRR.getMode() == RRR.Mode.REVISE) {
            g2.setColor(RRRCanvas2D.COLOR_REVISE_SHEET);
            g2.fill(sheet);
            g2.setStroke(RRRCanvas2D.STROKE_SHEET);
            sheets.add(sheet);
        } else {
            sheets.clear();
        }
        
        for(Rectangle2D rect : sheets) {
            g2.draw(rect);
        }
    }
    
    private void drawSheetInfo(Graphics2D g2) {
        String heading = null;
        if(this.mRRR.getMode() == RRR.Mode.QUESTION) {
            heading = "Question List";
            g2.setColor(RRRCanvas2D.COLOR_SHEET_INFO);
            g2.setFont(RRRCanvas2D.FONT_INFO);
            for(int i = 1; i < 17; i++) {
                g2.drawString(String.valueOf(i), 15, 
                    (float)(95 + 52.5 * (i - 1)));
            }
        } else if(this.mRRR.getMode() == RRR.Mode.REVISE) {
            heading = "Revise Sheet";
        } else {
            return;
        }
        
        g2.setColor(RRRCanvas2D.COLOR_SHEET_INFO);
        g2.setFont(RRRCanvas2D.FONT_INFO);
        g2.drawString(heading, (RRR.APP_WIDTH / 2) - 100 , 
            RRR.HEADER_HEIGHT - 10);
    }
    
    private void drawGuidelines(Graphics2D g2) {
        if(this.mRRR.getMode() == RRR.Mode.QUESTION) {
            int width = RRR.APP_WIDTH - 20;
            int height = RRR.APP_HEIGHT - RRR.HEADER_HEIGHT - 100;
                    
            Rectangle2D guidelineFrame = 
                new Rectangle2D.Double(10, 60, width, height);
            g2.setColor(RRRCanvas2D.COLOR_SHEET_INFO);
            g2.setStroke(RRRCanvas2D.STROKE_GUIDELINES);
            g2.draw(guidelineFrame);
            
            ArrayList<Line2D> guidelines = new ArrayList<Line2D>();
            for(int i = 0; i < 16; i++) {
                Line2D guideline = new Line2D.Double(10, 60 + 52.5 * i, 
                    width + 10, 60 + 52.5 * i);
                guidelines.add(guideline);
            }
            for(Line2D line : guidelines) {
                g2.draw(line);
            }
        }
        
        if(this.mRRR.getMode() == RRR.Mode.REVISE) {
            int width = RRR.APP_WIDTH - 20;
            int height = RRR.APP_HEIGHT - RRR.HEADER_HEIGHT - 100;
                    
            Rectangle2D guidelineFrame = 
                new Rectangle2D.Double(10, 60, width, height);
            g2.setColor(RRRCanvas2D.COLOR_SHEET_INFO);
            g2.setStroke(RRRCanvas2D.STROKE_GUIDELINES);
            g2.draw(guidelineFrame);
        }
    }
}