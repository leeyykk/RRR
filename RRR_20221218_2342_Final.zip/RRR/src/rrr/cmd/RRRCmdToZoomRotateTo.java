package rrr.cmd;

import java.awt.Point;
import rrr.RRR;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToZoomRotateTo extends XLoggableCmd {
    // fields
    private Point mPt = null;
    
    // constructor
    private RRRCmdToZoomRotateTo(XApp app, Point pt) {
        super(app);
        this.mPt = pt;
    }
    
    // methods
    public static boolean execute(XApp app, Point pt) {
        RRRCmdToZoomRotateTo cmd = new RRRCmdToZoomRotateTo(app, pt);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        rrr.getXform().zoomRotateTo(this.mPt);
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        sb.append(this.mPt);
        return sb.toString();
    }
}
