package rrr.cmd;

import java.awt.Point;
import java.awt.geom.Point2D;
import rrr.RRR;
import rrr.RRRPtCurve;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToUpdateCurPtCurve extends XLoggableCmd {
    // fields
    private Point mScreenPt = null;
    private Point2D.Double mWorldPt = null;
    
    // constructor
    private RRRCmdToUpdateCurPtCurve(XApp app, Point pt) {
        super(app);
        this.mScreenPt = pt;
    }
    
    // methods
    public static boolean execute(XApp app, Point pt) {
        RRRCmdToUpdateCurPtCurve cmd = new RRRCmdToUpdateCurPtCurve(app, pt);
        return cmd.execute();
    }

    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        RRRPtCurve curPtCurve = rrr.getPtCurveMgr().getCurPtCurve();
        
        int size = curPtCurve.getPts().size();
        Point2D.Double lastWorldPt = curPtCurve.getPts().get(size - 1);
        Point lastScreenPt = rrr.getXform().calcPtFromWorldToScreen(
            lastWorldPt);
        if(this.mScreenPt.distance(lastScreenPt) < 
            RRRPtCurve.MIN_DIST_BTWN_PTS) {
            return false;
        }
        this.mWorldPt = rrr.getXform().calcPtFromScreenToWorld(this.mScreenPt);
        curPtCurve.addPt(this.mWorldPt);
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        sb.append(this.mScreenPt).append("\t");
        sb.append(this.mWorldPt);
        return sb.toString();
    }
}