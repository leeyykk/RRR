package rrr.cmd;

import rrr.scenario.RRRSelectScenario;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToDestroySelectionBox extends XLoggableCmd {
    // constructor
    private RRRCmdToDestroySelectionBox(XApp app) {
        super(app);
    }
    
    // methods
    public static boolean execute(XApp app) {
        RRRCmdToDestroySelectionBox cmd = new RRRCmdToDestroySelectionBox(app);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRRSelectScenario.getSingleton().setSelectionBox(null);
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        return sb.toString();
    }
}
