package rrr.cmd;

import rrr.RRRUnderline;
import rrr.scenario.RRRReviseScenario;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToAddCurUnderlineToUnderlineList extends XLoggableCmd {
    // fields
    private int mNumOfUnderlinesBefore = Integer.MIN_VALUE;
    private int mNumOfUnderlinesAfter = Integer.MIN_VALUE;
    
    // constructor
    protected RRRCmdToAddCurUnderlineToUnderlineList(XApp app) {
        super(app);
    }
    
    // methods
    public static boolean execute(XApp app) {
        RRRCmdToAddCurUnderlineToUnderlineList cmd = 
            new RRRCmdToAddCurUnderlineToUnderlineList(app);
        return cmd.execute();
    }

    @Override
    protected boolean defineCmd() {
        RRRUnderline curUnderline = RRRReviseScenario.getSingleton().
            getCurUnderline();
        if(curUnderline != null && 
            curUnderline.getP1() != curUnderline.getP2()) {
            
            this.mNumOfUnderlinesBefore = 
                RRRReviseScenario.getSingleton().getUnderlineList().size();
            RRRReviseScenario.getSingleton().getUnderlineList().
                add(curUnderline);
            RRRReviseScenario.getSingleton().setCurUnderline(null);
            this.mNumOfUnderlinesAfter =
                RRRReviseScenario.getSingleton().getUnderlineList().size();
            return true;
        } else {
            return false;
        }
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        sb.append(this.mNumOfUnderlinesBefore).append("\t");
        sb.append(this.mNumOfUnderlinesAfter);
        return sb.toString();
    }
}
