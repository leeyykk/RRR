package rrr.cmd;

import rrr.RRR;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToDoSomething extends XLoggableCmd {
    // fields
    // ...
    
    // constructor
    private RRRCmdToDoSomething(XApp app) {
        super(app);
    }
    
    // methods
    public static boolean execute(XApp app) {
        RRRCmdToDoSomething cmd = new RRRCmdToDoSomething(app);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        // ...
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        // ...
        return sb.toString();
    }
}
