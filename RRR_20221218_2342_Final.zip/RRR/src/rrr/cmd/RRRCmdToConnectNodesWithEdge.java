package rrr.cmd;

import rrr.RRR;
import rrr.RRREdge;
import rrr.RRRNode;
import rrr.scenario.RRRReviseScenario;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToConnectNodesWithEdge extends XLoggableCmd {
    // fields
    private RRRNode mOldFirstNode = null;
    private RRRNode mOldSecondNode = null;
    private RRRNode mFirstNode = null;
    private RRRNode mSecondNode = null;
    private RRREdge mEdge = null;
    
    // constructor
    private RRRCmdToConnectNodesWithEdge(XApp app, RRRNode firstNode, 
        RRRNode secondNode, RRREdge edge) {
        
        super(app);
        this.mFirstNode = firstNode;
        this.mSecondNode = secondNode;
        this.mEdge = edge;
    }
    
    // methods
    public static boolean execute(XApp app, RRRNode firstNode, 
        RRRNode secondNode, RRREdge edge) {
        
        RRRCmdToConnectNodesWithEdge cmd = 
            new RRRCmdToConnectNodesWithEdge(app, firstNode, secondNode, edge);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        
        this.mOldFirstNode = this.mEdge.getFirstNode();
        if(this.mOldFirstNode != null) {
            this.mOldFirstNode.getStartEdgeList().remove(this.mEdge);
        }
        this.mOldSecondNode = this.mEdge.getSecondNode();
        if(this.mOldSecondNode != null) {
            this.mOldSecondNode.getEndEdgeList().remove(this.mEdge);
        }
        
        this.mEdge.setFirstNode(this.mFirstNode);
        this.mEdge.setSecondNode(this.mSecondNode);
        this.mFirstNode.getStartEdgeList().add(this.mEdge);
        this.mSecondNode.getEndEdgeList().add(this.mEdge);
        
        RRRReviseScenario.getSingleton().getFirstNode().
            setIsHighlighted(false);
        RRRReviseScenario.getSingleton().getSecondNode().
            setIsHighlighted(false);
        RRRReviseScenario.getSingleton().getSelectedGraphObject().
            setIsHighlighted(false);
        
        RRRReviseScenario.getSingleton().setFirstNode(null);
        RRRReviseScenario.getSingleton().setSecondNode(null);
        RRRReviseScenario.getSingleton().setSelectedGraphObject(null);
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        if(this.mOldFirstNode != null && this.mOldSecondNode != null) {
            sb.append(this.mOldFirstNode.getCenter()).append("\t");
            sb.append(this.mOldSecondNode.getCenter()).append("\t");
            sb.append(this.mOldFirstNode.getStartEdgeList().size()).append("\t");
            sb.append(this.mOldSecondNode.getEndEdgeList().size()).append("\t");
        }
        sb.append(this.mFirstNode.getCenter()).append("\t");
        sb.append(this.mSecondNode.getCenter()).append("\t");
        sb.append(this.mFirstNode.getStartEdgeList().size()).append("\t");
        sb.append(this.mSecondNode.getEndEdgeList().size());
        return sb.toString();
    }
}
