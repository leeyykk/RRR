package rrr.cmd;

import java.awt.Point;
import rrr.RRR;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToSetStartingScreenPt extends XLoggableCmd {
    // fields
    private Point mScreenPt = null;
    
    // constructor
    private RRRCmdToSetStartingScreenPt(XApp app, Point pt) {
        super(app);
        this.mScreenPt = pt;
    }
    
    // methods
    public static boolean execute(XApp app, Point pt) {
        RRRCmdToSetStartingScreenPt cmd = 
            new RRRCmdToSetStartingScreenPt(app, pt);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        rrr.getXform().setStartScreenPt(this.mScreenPt);
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        sb.append(this.mScreenPt);
        return sb.toString();
    }
}
