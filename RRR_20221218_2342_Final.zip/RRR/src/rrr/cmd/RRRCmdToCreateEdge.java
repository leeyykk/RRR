package rrr.cmd;

import java.awt.Point;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import rrr.RRR;
import rrr.RRREdge;
import rrr.RRRUnderline;
import rrr.scenario.RRRReviseScenario;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToCreateEdge extends XLoggableCmd {
    // constructor
    private RRRCmdToCreateEdge(XApp app) {
        super(app);
    }
    
    // methods
    public static boolean execute(XApp app) {
        RRRCmdToCreateEdge cmd = new RRRCmdToCreateEdge(app);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        
        ArrayList<RRRUnderline> underlineList = 
            RRRReviseScenario.getSingleton().getUnderlineList();
        for(RRRUnderline underline : underlineList) {
            Rectangle2D captureScreen = underline.getBounds2D();
            BufferedImage screenCopy = rrr.getCanvas2D().getImage().getSubimage(
                (int)captureScreen.getMinX(), (int)captureScreen.getMinY(),
                (int)captureScreen.getWidth(), (int)captureScreen.getHeight());
            Point startPt = new Point(
                (int)(underline.getP1().getX() - captureScreen.getWidth() / 2), 
                (int)underline.getP1().getY() - screenCopy.getHeight() / 2);
            Point endPt = new Point(
                (int)(underline.getP2().getX() + captureScreen.getWidth() / 2), 
                (int)underline.getP2().getY() - screenCopy.getHeight() / 2);
            RRREdge edge = new RRREdge(startPt, endPt, screenCopy);
            RRRReviseScenario.getSingleton().getEdgeList().add(edge);
        }
        
        RRRReviseScenario.getSingleton().getUnderlineList().clear();
        
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        sb.append(RRRReviseScenario.getSingleton().getEdgeList().size());
        return sb.toString();
    }
}
