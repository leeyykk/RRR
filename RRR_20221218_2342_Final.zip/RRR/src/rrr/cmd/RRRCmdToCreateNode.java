package rrr.cmd;

import java.awt.Point;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import rrr.RRR;
import rrr.RRRNode;
import rrr.RRRUnderline;
import rrr.scenario.RRRReviseScenario;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToCreateNode extends XLoggableCmd {
    // constructor
    private RRRCmdToCreateNode(XApp app) {
        super(app);
    }
    
    // methods
    public static boolean execute(XApp app) {
        RRRCmdToCreateNode cmd = new RRRCmdToCreateNode(app);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        
        ArrayList<RRRUnderline> underlineList = 
            RRRReviseScenario.getSingleton().getUnderlineList();
        for(RRRUnderline underline : underlineList) {
            Rectangle2D captureScreen = underline.getBounds2D();
            BufferedImage screenCopy = rrr.getCanvas2D().getImage().getSubimage(
                (int)captureScreen.getMinX(), (int)captureScreen.getMinY(),
                (int)captureScreen.getWidth(), (int)captureScreen.getHeight());
            RRRNode node = new RRRNode((Point) underline.getP1(), screenCopy);
            RRRReviseScenario.getSingleton().getNodeList().add(node);
        }
        
        RRRReviseScenario.getSingleton().getUnderlineList().clear();
        
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        sb.append(RRRReviseScenario.getSingleton().getNodeList().size());
        return sb.toString();
    }
}
