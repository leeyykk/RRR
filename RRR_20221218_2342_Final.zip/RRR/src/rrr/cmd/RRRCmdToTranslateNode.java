package rrr.cmd;

import java.awt.Point;
import java.util.ArrayList;
import rrr.RRR;
import rrr.RRREdge;
import rrr.RRRNode;
import rrr.scenario.RRRReviseScenario;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToTranslateNode extends XLoggableCmd {
    // fields
    private Point mPrevPt = null;
    private Point mPt = null;
    
    // constructor
    private RRRCmdToTranslateNode(XApp app, Point pt) {
        super(app);
        this.mPt = pt;
    }
    
    // methods
    public static boolean execute(XApp app, Point pt) {
        RRRCmdToTranslateNode cmd = new RRRCmdToTranslateNode(app, pt);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        RRRNode node = (RRRNode) RRRReviseScenario.getSingleton().
            getSelectedGraphObject();
        if(node.getCenter() != null) {
            this.mPrevPt = node.getCenter();
        }
        node.setCenter(this.mPt);

        ArrayList<RRREdge> startEdgeList = node.getStartEdgeList();
        for(RRREdge edge : startEdgeList) {
            edge.setStartPt(this.mPt);
        }
        ArrayList<RRREdge> endEdgeList = node.getEndEdgeList();
        for(RRREdge edge : endEdgeList) {
            edge.setEndPt(this.mPt);
        }
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        sb.append(this.mPrevPt).append("\t");
        sb.append(this.mPt);
        return sb.toString();
    }
}
