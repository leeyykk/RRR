package rrr.cmd;

import rrr.RRR;
import rrr.RRRPtCurve;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToAddCurPtCurveToPtCurves extends XLoggableCmd {
    // fields
    private int mNumOfPtCurvesBefore = Integer.MIN_VALUE;
    private int mNumOfPtCurvesAfter = Integer.MIN_VALUE;
    
    // constructor
    protected RRRCmdToAddCurPtCurveToPtCurves(XApp app) {
        super(app);
    }
    
    // methods
    public static boolean execute(XApp app) {
        RRRCmdToAddCurPtCurveToPtCurves cmd = 
            new RRRCmdToAddCurPtCurveToPtCurves(app);
        return cmd.execute();
    }

    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        RRRPtCurve curPtCurve = rrr.getPtCurveMgr().getCurPtCurve();
        if(curPtCurve.getPts().size() >= 2) {
            this.mNumOfPtCurvesBefore = 
                rrr.getPtCurveMgr().getPtCurves().size();
            rrr.getPtCurveMgr().getPtCurves().add(curPtCurve);
            this.mNumOfPtCurvesAfter =
                rrr.getPtCurveMgr().getPtCurves().size();
            return true;
        } else {
            return false;
        }
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        sb.append(this.mNumOfPtCurvesBefore).append("\t");
        sb.append(this.mNumOfPtCurvesAfter);
        return sb.toString();
    }
}
