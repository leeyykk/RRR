package rrr.cmd;

import java.awt.Point;
import java.awt.geom.Point2D;
import rrr.RRR;
import rrr.RRRPtCurve;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToCreateCurPtCurve extends XLoggableCmd {
    // fields
    private Point mScreenPt = null;
    private Point2D.Double mWorldPt = null;
    
    // constructor
    private RRRCmdToCreateCurPtCurve(XApp app, Point pt) {
        super(app);
        this.mScreenPt = pt;
    }
    
    // methods
    public static boolean execute(XApp app, Point pt) {
        RRRCmdToCreateCurPtCurve cmd = new RRRCmdToCreateCurPtCurve(app, pt);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        this.mWorldPt = rrr.getXform().calcPtFromScreenToWorld(this.mScreenPt);
        RRRPtCurve ptCurve = new RRRPtCurve(this.mWorldPt, 
            rrr.getCanvas2D().getCurColorForPtCurve(),
            rrr.getCanvas2D().getCurStrokeForPtCurve());
        rrr.getPtCurveMgr().setCurPtCurve(ptCurve);
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        sb.append(this.mScreenPt).append("\t");
        sb.append(this.mWorldPt);
        return sb.toString();
    }
}
