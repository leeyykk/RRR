package rrr.cmd;

import rrr.RRR;
import rrr.RRREdge;
import rrr.RRRNode;
import rrr.scenario.RRRReviseScenario;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToDeleteSelectedEdge extends XLoggableCmd {
    // constructor
    private RRRCmdToDeleteSelectedEdge(XApp app) {
        super(app);
    }
    
    // methods
    public static boolean execute(XApp app) {
        RRRCmdToDeleteSelectedEdge cmd = 
            new RRRCmdToDeleteSelectedEdge(app);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        RRREdge selectedEdge = (RRREdge) RRRReviseScenario.getSingleton().
            getSelectedGraphObject();
        
        RRRNode firstNode = RRRReviseScenario.getSingleton()
            .getFirstNode();
        if(firstNode != null) {
            firstNode.setIsHighlighted(false);
            RRRReviseScenario.getSingleton().setFirstNode(null);
        }
        RRRNode secondNode = RRRReviseScenario.getSingleton()
            .getSecondNode();
        if(secondNode != null) {
            secondNode.setIsHighlighted(false);
            RRRReviseScenario.getSingleton().setSecondNode(null);
        }
        
        RRRNode firstConnectedNode = selectedEdge.getFirstNode();
        if(firstConnectedNode != null) {
            firstConnectedNode.getStartEdgeList().remove(selectedEdge);
            selectedEdge.setFirstNode(null);
        }
        RRRNode secondConnectedNode = selectedEdge.getSecondNode();
        if(secondConnectedNode != null) {
            secondConnectedNode.getEndEdgeList().remove(selectedEdge);
            selectedEdge.setSecondNode(null);
        }
        
        RRRReviseScenario.getSingleton().getEdgeList()
            .remove(selectedEdge);
        RRRReviseScenario.getSingleton().setSelectedGraphObject(null);
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName());
        return sb.toString();
    }
}
