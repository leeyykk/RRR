package rrr.cmd;

import java.awt.Point;
import rrr.RRR;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToTranslateTo extends XLoggableCmd {
    // fields
    private Point mPt = null;
    
    // constructor
    private RRRCmdToTranslateTo(XApp app, Point pt) {
        super(app);
        this.mPt = pt;
    }
    
    // methods
    public static boolean execute(XApp app, Point pt) {
        RRRCmdToTranslateTo cmd = new RRRCmdToTranslateTo(app, pt);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        rrr.getXform().translateTo(this.mPt);
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        sb.append(this.mPt);
        return sb.toString();
    }
}
