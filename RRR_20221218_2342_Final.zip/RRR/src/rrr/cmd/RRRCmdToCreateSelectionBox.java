package rrr.cmd;

import java.awt.Point;
import rrr.RRRSelectionBox;
import rrr.scenario.RRRSelectScenario;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToCreateSelectionBox extends XLoggableCmd {
    // fields
    private Point mPt = null;
    
    // constructor
    private RRRCmdToCreateSelectionBox(XApp app, Point pt) {
        super(app);
        this.mPt = pt;
    }
    
    // methods
    public static boolean execute(XApp app, Point pt) {
        RRRCmdToCreateSelectionBox cmd = new RRRCmdToCreateSelectionBox(app, pt);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRRSelectionBox selectionBox = new RRRSelectionBox(this.mPt);
        RRRSelectScenario.getSingleton().setSelectionBox(selectionBox);
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        sb.append(this.mPt);
        return sb.toString();
    }
}
