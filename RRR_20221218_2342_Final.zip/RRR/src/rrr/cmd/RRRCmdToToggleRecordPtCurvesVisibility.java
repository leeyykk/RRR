package rrr.cmd;

import rrr.RRR;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToToggleRecordPtCurvesVisibility extends XLoggableCmd {
    // fields
    private boolean mRecordPtCurvesVisibility = false;
    
    // constructor
    private RRRCmdToToggleRecordPtCurvesVisibility(XApp app) {
        super(app);
    }
    
    // methods
    public static boolean execute(XApp app) {
        RRRCmdToToggleRecordPtCurvesVisibility cmd = 
            new RRRCmdToToggleRecordPtCurvesVisibility(app);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        rrr.getPtCurveMgr().toggleRecordPtCurvesVisibility();
        this.mRecordPtCurvesVisibility = 
            rrr.getPtCurveMgr().getRecordPtCurvesVisibility();
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        sb.append(this.mRecordPtCurvesVisibility);
        return sb.toString();
    }
}
