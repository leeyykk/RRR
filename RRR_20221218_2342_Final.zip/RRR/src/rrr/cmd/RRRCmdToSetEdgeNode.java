package rrr.cmd;

import rrr.RRR;
import rrr.RRRNode;
import rrr.scenario.RRRReviseScenario;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToSetEdgeNode extends XLoggableCmd {
    // fields
    RRRNode mNode = null;
    private int mNodeNum = 0;
    
    // constructor
    private RRRCmdToSetEdgeNode(XApp app, RRRNode node, int num) {
        super(app);
        this.mNode = node;
        this.mNodeNum = num;
    }
    
    // methods
    public static boolean execute(XApp app, RRRNode node, int num) {
        RRRCmdToSetEdgeNode cmd = new RRRCmdToSetEdgeNode(app, node, num);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        if(this.mNodeNum == 1) {
            RRRReviseScenario.getSingleton().setFirstNode(this.mNode);
        } else if(this.mNodeNum == 2) {
            RRRReviseScenario.getSingleton().setSecondNode(this.mNode);
        }
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        sb.append(this.mNode).append("\t");
        sb.append(this.mNodeNum);
        return sb.toString();
    }
}
