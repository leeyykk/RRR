package rrr.cmd;

import java.awt.Point;
import rrr.RRRUnderline;
import rrr.scenario.RRRReviseScenario;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToCreateUnderline extends XLoggableCmd {
    // fields
    private Point mPt = null;
    
    // constructor
    private RRRCmdToCreateUnderline(XApp app, Point pt) {
        super(app);
        this.mPt = pt;
    }
    
    // methods
    public static boolean execute(XApp app, Point pt) {
        RRRCmdToCreateUnderline cmd = new RRRCmdToCreateUnderline(app, pt);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRRUnderline underline = new RRRUnderline(this.mPt);
        RRRReviseScenario.getSingleton().setCurUnderline(underline);
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        sb.append(this.mPt);
        return sb.toString();
    }
}
