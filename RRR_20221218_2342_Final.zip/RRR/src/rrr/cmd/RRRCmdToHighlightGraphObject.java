package rrr.cmd;

import rrr.RRR;
import rrr.RRRGraphObject;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToHighlightGraphObject extends XLoggableCmd {
    // fields
    private RRRGraphObject mObject = null;
    private boolean mState = false;
    
    // constructor
    private RRRCmdToHighlightGraphObject(XApp app, RRRGraphObject object, 
        boolean state) {
        
        super(app);
        this.mObject = object;
        this.mState = state;
    }
    
    // methods
    public static boolean execute(XApp app, RRRGraphObject object, 
        boolean state) {
        
        RRRCmdToHighlightGraphObject cmd = 
            new RRRCmdToHighlightGraphObject(app, object, state);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        if(this.mObject != null) {
            this.mObject.setIsHighlighted(this.mState);
        }
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        return sb.toString();
    }
}
