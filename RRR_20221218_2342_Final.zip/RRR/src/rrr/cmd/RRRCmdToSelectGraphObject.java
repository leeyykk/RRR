package rrr.cmd;

import rrr.RRR;
import rrr.RRRGraphObject;
import rrr.scenario.RRRReviseScenario;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToSelectGraphObject extends XLoggableCmd {
    // fields
    private RRRGraphObject mObject = null;
    
    // constructor
    private RRRCmdToSelectGraphObject(XApp app, RRRGraphObject object) {
        super(app);
        this.mObject = object;
    }
    
    // methods
    public static boolean execute(XApp app, RRRGraphObject object) {
        RRRCmdToSelectGraphObject cmd = 
            new RRRCmdToSelectGraphObject(app, object);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        RRRReviseScenario.getSingleton().
            setSelectedGraphObject(this.mObject);
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        sb.append(this.mObject);
        return sb.toString();
    }
}
