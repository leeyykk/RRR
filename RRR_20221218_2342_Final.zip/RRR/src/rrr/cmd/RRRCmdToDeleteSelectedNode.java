package rrr.cmd;

import rrr.RRR;
import rrr.RRREdge;
import rrr.RRRNode;
import rrr.scenario.RRRReviseScenario;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToDeleteSelectedNode extends XLoggableCmd {
    // constructor
    private RRRCmdToDeleteSelectedNode(XApp app) {
        super(app);
    }
    
    // methods
    public static boolean execute(XApp app) {
        RRRCmdToDeleteSelectedNode cmd = 
            new RRRCmdToDeleteSelectedNode(app);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        RRRNode selectedNode = (RRRNode) RRRReviseScenario.getSingleton().
            getSelectedGraphObject();
        for(RRREdge edge : selectedNode.getStartEdgeList()) {
            edge.setFirstNode(null);
            edge.getSecondNode().getEndEdgeList().remove(edge);
            edge.setSecondNode(null);
        }
        selectedNode.getStartEdgeList().clear();
        for(RRREdge edge : selectedNode.getEndEdgeList()) {
            edge.getFirstNode().getStartEdgeList().remove(edge);
            edge.setFirstNode(null);
            edge.setSecondNode(null);
        }
        selectedNode.getEndEdgeList().clear();
        RRRReviseScenario.getSingleton().getNodeList().remove(selectedNode);
        RRRReviseScenario.getSingleton().setSelectedGraphObject(null);
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName());
        return sb.toString();
    }
}
