package rrr.cmd;

import rrr.RRR;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToDeleteRecentQuestionPtCurve extends XLoggableCmd {
    // constructor
    private RRRCmdToDeleteRecentQuestionPtCurve(XApp app) {
        super(app);
    }
    
    // methods
    public static boolean execute(XApp app) {
        RRRCmdToDeleteRecentQuestionPtCurve cmd = 
            new RRRCmdToDeleteRecentQuestionPtCurve(app);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        if(!rrr.getPtCurveMgr().getQuestionPtCurves().isEmpty()) {
            rrr.getPtCurveMgr().deleteLastQuestionPtCurves();
        }
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName());
        return sb.toString();
    }
}
