package rrr.cmd;

import java.awt.Point;
import rrr.RRRUnderline;
import rrr.scenario.RRRReviseScenario;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToUpdateUnderline extends XLoggableCmd {
    // fields
    Point mPt = null;
    RRRUnderline curUnderline = null;
    
    // constructor
    private RRRCmdToUpdateUnderline(XApp app, Point pt) {
        super(app);
        this.mPt = pt;
    }
    
    // methods
    public static boolean execute(XApp app, Point pt) {
        RRRCmdToUpdateUnderline cmd = new RRRCmdToUpdateUnderline(app, pt);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        this.curUnderline = 
            RRRReviseScenario.getSingleton().getCurUnderline();
        if(this.curUnderline.getStartPt().x < this.mPt.x) {
            this.curUnderline.update(this.mPt);
        }
        RRRReviseScenario.getSingleton().setCurUnderline(this.curUnderline);
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        sb.append(this.curUnderline.getP1()).append("\t");
        sb.append(this.curUnderline.getP2());
        return sb.toString();
    }
}