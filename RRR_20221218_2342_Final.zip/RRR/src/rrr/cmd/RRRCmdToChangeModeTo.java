package rrr.cmd;

import rrr.RRR;
import rrr.RRR.Mode;
import rrr.RRRGraphObject;
import rrr.RRRNode;
import rrr.scenario.RRRReviseScenario;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToChangeModeTo extends XLoggableCmd {
    // fields
    private Mode mPrevMode = null;
    private Mode mMode = null;
    
    // constructor
    private RRRCmdToChangeModeTo(XApp app, Mode mode) {
        super(app);
        this.mMode = mode;
    }
    
    // methods
    public static boolean execute(XApp app, Mode mode) {
        RRRCmdToChangeModeTo cmd = new RRRCmdToChangeModeTo(app, mode);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        
        this.mPrevMode = rrr.getMode();
        if(this.mPrevMode == RRR.Mode.REVISE) {
            RRRGraphObject object = RRRReviseScenario.getSingleton().
                getSelectedGraphObject();
            if(object != null) {
                object.setIsHighlighted(false);
                RRRReviseScenario.getSingleton().setSelectedGraphObject(null);
            }
            
            RRRNode firstNode = RRRReviseScenario.getSingleton().
                getFirstNode();
            if(firstNode != null) {
                firstNode.setIsHighlighted(false);
                RRRReviseScenario.getSingleton().setFirstNode(null);
            }
            RRRNode secondNode = RRRReviseScenario.getSingleton().
                getSecondNode();
            if(secondNode != null) {
                secondNode.setIsHighlighted(false);
                RRRReviseScenario.getSingleton().setSecondNode(null);
            }
        }
        
        rrr.setMode(this.mMode);
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        sb.append(this.mPrevMode.toString()).append("\t");
        sb.append(this.mMode.toString());
        return sb.toString();
    }
}
