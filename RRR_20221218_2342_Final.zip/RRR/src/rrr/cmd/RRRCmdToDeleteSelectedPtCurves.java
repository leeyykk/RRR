package rrr.cmd;

import rrr.RRR;
import rrr.RRRPtCurveMgr;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToDeleteSelectedPtCurves extends XLoggableCmd {
    // constructor
    private RRRCmdToDeleteSelectedPtCurves(XApp app) {
        super(app);
    }
    
    // methods
    public static boolean execute(XApp app) {
        RRRCmdToDeleteSelectedPtCurves cmd = 
            new RRRCmdToDeleteSelectedPtCurves(app);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        RRRPtCurveMgr ptCurveMgr = rrr.getPtCurveMgr();
        ptCurveMgr.getSelectedPtCurves().clear();
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName());
        return sb.toString();
    }
}
