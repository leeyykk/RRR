package rrr.cmd;

import java.awt.Point;
import rrr.RRR;
import rrr.RRRSelectionBox;
import rrr.scenario.RRRSelectScenario;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToUpdateSelectionBox extends XLoggableCmd {
    // fields
    private Point mScreenPt = null;
    private RRRSelectionBox mSelectionBox = null;
    
    // constructor
    private RRRCmdToUpdateSelectionBox(XApp app, Point pt) {
        super(app);
        this.mScreenPt = pt;
        this.mSelectionBox = new RRRSelectionBox(pt);
    }
    
    // methods
    public static boolean execute(XApp app, Point pt) {
        RRRCmdToUpdateSelectionBox cmd = 
            new RRRCmdToUpdateSelectionBox(app, pt);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        RRRSelectScenario scenario = RRRSelectScenario.getSingleton();
        scenario.getSelectionBox().update(this.mScreenPt);
        this.mSelectionBox = scenario.getSelectionBox();
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        sb.append(this.mScreenPt).append("\t");
        sb.append(this.mSelectionBox);
        return sb.toString();
    }
}
