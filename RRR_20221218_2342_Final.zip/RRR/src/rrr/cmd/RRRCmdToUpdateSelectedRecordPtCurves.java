package rrr.cmd;

import rrr.RRR;
import rrr.scenario.RRRSelectScenario;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToUpdateSelectedRecordPtCurves extends XLoggableCmd {
    // fields
    private int mNumOfSelectedPtCurves = Integer.MIN_VALUE;
    
    // constructor
    private RRRCmdToUpdateSelectedRecordPtCurves(XApp app) {
        super(app);
    }
    
    // methods
    public static boolean execute(XApp app) {
        RRRCmdToUpdateSelectedRecordPtCurves cmd = 
            new RRRCmdToUpdateSelectedRecordPtCurves(app);
        return cmd.execute();   
    }
    
    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        RRRSelectScenario.getSingleton().updateSelectedRecordPtCurves();
        this.mNumOfSelectedPtCurves = 
            rrr.getPtCurveMgr().getSelectedPtCurves().size();
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        sb.append(this.mNumOfSelectedPtCurves);
        return sb.toString();
    }
}
