package rrr.cmd;

import java.util.ArrayList;
import rrr.RRR;
import rrr.RRRPtCurve;
import x.XApp;
import x.XLoggableCmd;

public class RRRCmdToAddSelectedPtCurvesToRevisePtCurves extends XLoggableCmd {
    // fields
    private int mNumOfPtCurvesBefore = Integer.MIN_VALUE;
    private int mNumOfPtCurvesAfter = Integer.MIN_VALUE;
    
    // constructor
    protected RRRCmdToAddSelectedPtCurvesToRevisePtCurves(XApp app) {
        super(app);
    }
    
    // methods
    public static boolean execute(XApp app) {
        RRRCmdToAddSelectedPtCurvesToRevisePtCurves cmd = 
            new RRRCmdToAddSelectedPtCurvesToRevisePtCurves(app);
        return cmd.execute();
    }

    @Override
    protected boolean defineCmd() {
        RRR rrr = (RRR) this.mApp;
        ArrayList<RRRPtCurve> ptCurves = rrr.getPtCurveMgr().
            getSelectedPtCurves();
        this.mNumOfPtCurvesBefore = 
            rrr.getPtCurveMgr().getRevisePtCurves().size();
        for(RRRPtCurve ptCurve : ptCurves) {
            rrr.getPtCurveMgr().getRevisePtCurves().add(ptCurve);
        }
        this.mNumOfPtCurvesAfter =
            rrr.getPtCurveMgr().getRevisePtCurves().size();
        rrr.getPtCurveMgr().getSelectedPtCurves().clear();
        return true;
    }

    @Override
    protected String createLog() {
        StringBuffer sb = new StringBuffer();
        sb.append(this.getClass().getSimpleName()).append("\t");
        sb.append(this.mNumOfPtCurvesBefore).append("\t");
        sb.append(this.mNumOfPtCurvesAfter);
        return sb.toString();
    }
}
