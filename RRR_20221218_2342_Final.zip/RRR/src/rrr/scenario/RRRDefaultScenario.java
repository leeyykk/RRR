package rrr.scenario;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import rrr.RRR;
import rrr.RRRScene;
import rrr.cmd.RRRCmdToCreateCurPtCurve;
import x.XApp;
import x.XCmdToChangeScene;
import x.XScenario;

public class RRRDefaultScenario extends XScenario {
    // singleton pattern
    private static RRRDefaultScenario mSingleton = null;
    public static RRRDefaultScenario createSingleton(XApp app) {
        assert(RRRDefaultScenario.mSingleton == null);
        RRRDefaultScenario.mSingleton = new RRRDefaultScenario(app);
        return RRRDefaultScenario.mSingleton;
    }
    public static RRRDefaultScenario getSingleton() {
        assert(RRRDefaultScenario.mSingleton != null);
        return RRRDefaultScenario.mSingleton;
    }
    private RRRDefaultScenario(XApp app) {
        super(app);
    }  
    
    // methods
    @Override
    protected void addScenes() {
        this.addScene(RRRDefaultScenario.ReadyScene.createSingleton(this));
    }

    public static class ReadyScene extends RRRScene {
        // singleton pattern
        private static ReadyScene mSingleton = null;
        public static ReadyScene createSingleton(XScenario scenario) {
            assert(ReadyScene.mSingleton == null);
            ReadyScene.mSingleton = new ReadyScene(scenario);
            return ReadyScene.mSingleton;
        }
        public static ReadyScene getSingleton() {
            assert(ReadyScene.mSingleton != null);
            return ReadyScene.mSingleton;
        }
        protected ReadyScene(XScenario scenario) {
            super(scenario);
        }

        @Override
        public void handleMousePress(MouseEvent e) {
            RRR rrr = (RRR) this.mScenario.getApp();
            if(rrr.getMode() != RRR.Mode.NONE) {
                Point pt = e.getPoint();
                RRRCmdToCreateCurPtCurve.execute(rrr, pt);
            
                XCmdToChangeScene.execute(rrr, 
                    RRRDrawScenario.DrawScene.getSingleton(), this);
            }
        }

        @Override
        public void handleMouseDrag(MouseEvent e) {
        }

        @Override
        public void handleMouseRelease(MouseEvent e) {
        }

        @Override
        public void handleKeyDown(KeyEvent e) {
            RRR rrr = (RRR) this.mScenario.getApp();
            int code = e.getKeyCode();
            switch(code) {
                case KeyEvent.VK_SHIFT:
                    XCmdToChangeScene.execute(rrr, 
                        RRRSelectScenario.SelectReadyScene.getSingleton(), 
                        this);
                    break;
            }
        }

        @Override
        public void handleKeyUp(KeyEvent e) {
        }

        @Override
        public void updateSupportObjects() {
        }

        @Override
        public void renderWorldObjects(Graphics2D g2) {
        }

        @Override
        public void renderScreenObjects(Graphics2D g2) {
        }

        @Override
        public void getReady() {
        }

        @Override
        public void wrapUp() {
        }
    }
}
