package rrr.scenario;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import rrr.RRR;
import rrr.RRRScene;
import rrr.cmd.RRRCmdToDeleteSelectedPtCurves;
import rrr.cmd.RRRCmdToDeselectSelectedPtCurves;
import rrr.cmd.RRRCmdToSetStartingScreenPt;
import rrr.cmd.RRRCmdToTranslateTo;
import rrr.cmd.RRRCmdToZoomRotateTo;
import x.XApp;
import x.XCmdToChangeScene;
import x.XScenario;

public class RRRNavigateScenario extends XScenario {
    // singleton pattern
    private static RRRNavigateScenario mSingleton = null;
    public static RRRNavigateScenario createSingleton(XApp app) {
        assert(RRRNavigateScenario.mSingleton == null);
        RRRNavigateScenario.mSingleton = new RRRNavigateScenario(app);
        return RRRNavigateScenario.mSingleton;
    }
    public static RRRNavigateScenario getSingleton() {
        assert(RRRNavigateScenario.mSingleton != null);
        return RRRNavigateScenario.mSingleton;
    }
    private RRRNavigateScenario(XApp app) {
        super(app);
    }
    
    // methods
    @Override
    protected void addScenes() {
        this.addScene(
            RRRNavigateScenario.ZoomRotateReadyScene.createSingleton(this));
        this.addScene(
            RRRNavigateScenario.ZoomRotateScene.createSingleton(this));
        this.addScene(RRRNavigateScenario.PanReadyScene.createSingleton(this));
        this.addScene(RRRNavigateScenario.PanScene.createSingleton(this));
    }

    public static class ZoomRotateReadyScene extends RRRScene {
        // singleton pattern
        private static ZoomRotateReadyScene mSingleton = null;
        public static ZoomRotateReadyScene createSingleton(XScenario scenario) {
            assert(ZoomRotateReadyScene.mSingleton == null);
            ZoomRotateReadyScene.mSingleton = 
                new ZoomRotateReadyScene(scenario);
            return ZoomRotateReadyScene.mSingleton;
        }
        public static ZoomRotateReadyScene getSingleton() {
            assert(ZoomRotateReadyScene.mSingleton != null);
            return ZoomRotateReadyScene.mSingleton;
        }
        private ZoomRotateReadyScene(XScenario scenario) {
            super(scenario);
        }

        @Override
        public void handleMousePress(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            Point pt = e.getPoint();
            RRRCmdToSetStartingScreenPt.execute(rrr, pt);
            
            XCmdToChangeScene.execute(rrr, 
                RRRNavigateScenario.ZoomRotateScene.getSingleton(), 
                this.mReturnScene);
        }

        @Override
        public void handleMouseDrag(MouseEvent e) {
        }

        @Override
        public void handleMouseRelease(MouseEvent e) {
        }

        @Override
        public void handleKeyDown(KeyEvent e) {
        }

        @Override
        public void handleKeyUp(KeyEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            int code = e.getKeyCode();
            switch(code) {
                case KeyEvent.VK_ALT:
                    XCmdToChangeScene.execute(rrr, 
                        RRRSelectScenario.SelectedReadyScene.getSingleton(), 
                        null);
                    break;
            }
        }

        @Override
        public void updateSupportObjects() {
        }

        @Override
        public void renderWorldObjects(Graphics2D g2) {
        }

        @Override
        public void renderScreenObjects(Graphics2D g2) {            
            RRR rrr = (RRR)this.mScenario.getApp();            
            if(rrr.getMode() == RRR.Mode.REVISE) {
                RRRReviseScenario.getSingleton().drawEdgeList(g2);
                RRRReviseScenario.getSingleton().drawNodeList(g2);
            }
        }

        @Override
        public void getReady() {
        }

        @Override
        public void wrapUp() {
        }
    }
    
    public static class ZoomRotateScene extends RRRScene {
        // singleton pattern
        private static ZoomRotateScene mSingleton = null;
        public static ZoomRotateScene createSingleton(XScenario scenario) {
            assert(ZoomRotateScene.mSingleton == null);
            ZoomRotateScene.mSingleton = new ZoomRotateScene(scenario);
            return ZoomRotateScene.mSingleton;
        }
        public static ZoomRotateScene getSingleton() {
            assert(ZoomRotateScene.mSingleton != null);
            return ZoomRotateScene.mSingleton;
        }
        private ZoomRotateScene(XScenario scenario) {
            super(scenario);
        }

        @Override
        public void handleMousePress(MouseEvent e) {
        }

        @Override
        public void handleMouseDrag(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            Point pt = e.getPoint();
            RRRCmdToZoomRotateTo.execute(rrr, pt);
        }

        @Override
        public void handleMouseRelease(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            RRRCmdToSetStartingScreenPt.execute(rrr, null);
            
            XCmdToChangeScene.execute(rrr, 
                RRRNavigateScenario.ZoomRotateReadyScene.getSingleton(), 
                this.mReturnScene);
        }

        @Override
        public void handleKeyDown(KeyEvent e) {
        }

        @Override
        public void handleKeyUp(KeyEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            int code = e.getKeyCode();
            switch(code) {
                case KeyEvent.VK_ALT:
                    XCmdToChangeScene.execute(rrr, 
                        RRRSelectScenario.SelectedReadyScene.getSingleton(), 
                        null);
                    break;
            }
        }

        @Override
        public void updateSupportObjects() {
        }

        @Override
        public void renderWorldObjects(Graphics2D g2) {
        }

        @Override
        public void renderScreenObjects(Graphics2D g2) {
            RRR rrr = (RRR)this.mScenario.getApp();            
            if(rrr.getMode() == RRR.Mode.REVISE) {
                RRRReviseScenario.getSingleton().drawEdgeList(g2);
                RRRReviseScenario.getSingleton().drawNodeList(g2);
            }
        }

        @Override
        public void getReady() {
        }

        @Override
        public void wrapUp() {
        }
    }
    
    public static class PanReadyScene extends RRRScene {
        // singleton pattern
        private static PanReadyScene mSingleton = null;
        public static PanReadyScene createSingleton(XScenario scenario) {
            assert(PanReadyScene.mSingleton == null);
            PanReadyScene.mSingleton = new PanReadyScene(scenario);
            return PanReadyScene.mSingleton;
        }
        public static PanReadyScene getSingleton() {
            assert(PanReadyScene.mSingleton != null);
            return PanReadyScene.mSingleton;
        }
        private PanReadyScene(XScenario scenario) {
            super(scenario);
        }

        @Override
        public void handleMousePress(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            Point pt = e.getPoint();
            RRRCmdToSetStartingScreenPt.execute(rrr, pt);
            
            XCmdToChangeScene.execute(rrr, 
                RRRNavigateScenario.PanScene.getSingleton(), 
                this.mReturnScene);
        }

        @Override
        public void handleMouseDrag(MouseEvent e) {
        }

        @Override
        public void handleMouseRelease(MouseEvent e) {
            
        }

        @Override
        public void handleKeyDown(KeyEvent e) {
        }

        @Override
        public void handleKeyUp(KeyEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            int code = e.getKeyCode();
            switch(code) {
                case KeyEvent.VK_CONTROL:
                    XCmdToChangeScene.execute(rrr, 
                        RRRSelectScenario.SelectedReadyScene.getSingleton(), 
                        null);
                    break;
                case KeyEvent.VK_BACK_SPACE:
                    if(rrr.getMode() == RRR.Mode.REVISE) {
                        RRRCmdToDeleteSelectedPtCurves.execute(rrr);
                        
                        XCmdToChangeScene.execute(rrr, 
                            RRRReviseScenario.ReviseReadyScene.getSingleton(), 
                            null);
                    }
                    break;
            }
        }

        @Override
        public void updateSupportObjects() {
        }

        @Override
        public void renderWorldObjects(Graphics2D g2) {
        }

        @Override
        public void renderScreenObjects(Graphics2D g2) {
            RRR rrr = (RRR)this.mScenario.getApp(); 
            if(rrr.getMode() == RRR.Mode.REVISE) {
                RRRReviseScenario.getSingleton().drawEdgeList(g2);
                RRRReviseScenario.getSingleton().drawNodeList(g2);
            }
        }

        @Override
        public void getReady() {
        }

        @Override
        public void wrapUp() {
        }
    }
    
    public static class PanScene extends RRRScene {
        // singleton pattern
        private static PanScene mSingleton = null;
        public static PanScene createSingleton(XScenario scenario) {
            assert(PanScene.mSingleton == null);
            PanScene.mSingleton = new PanScene(scenario);
            return PanScene.mSingleton;
        }
        public static PanScene getSingleton() {
            assert(PanScene.mSingleton != null);
            return PanScene.mSingleton;
        }
        private PanScene(XScenario scenario) {
            super(scenario);
        }

        @Override
        public void handleMousePress(MouseEvent e) {
        }

        @Override
        public void handleMouseDrag(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            Point pt = e.getPoint();
            RRRCmdToTranslateTo.execute(rrr, pt);
        }

        @Override
        public void handleMouseRelease(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();            
            RRRCmdToSetStartingScreenPt.execute(rrr, null);

            if(rrr.getMode() == RRR.Mode.REVISE) {
                RRRCmdToDeselectSelectedPtCurves.execute(rrr);
                
                XCmdToChangeScene.execute(rrr, 
                    RRRReviseScenario.ReviseReadyScene.getSingleton(), 
                    this.mReturnScene);
            } else {
                XCmdToChangeScene.execute(rrr, 
                    RRRNavigateScenario.PanReadyScene.getSingleton(), 
                    this.mReturnScene);
            }
        }

        @Override
        public void handleKeyDown(KeyEvent e) {
        }

        @Override
        public void handleKeyUp(KeyEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            int code = e.getKeyCode();
            switch(code) {
                case KeyEvent.VK_CONTROL:
                    if(rrr.getPtCurveMgr().getSelectedPtCurves().isEmpty()) {
                        XCmdToChangeScene.execute(rrr, 
                            RRRDefaultScenario.ReadyScene.getSingleton(), null);
                    } else {
                        XCmdToChangeScene.execute(rrr, 
                            RRRSelectScenario.SelectedReadyScene.getSingleton(), 
                            null);
                    }
                    break;
            }
        }

        @Override
        public void updateSupportObjects() {
        }

        @Override
        public void renderWorldObjects(Graphics2D g2) {
        }

        @Override
        public void renderScreenObjects(Graphics2D g2) {
            RRR rrr = (RRR)this.mScenario.getApp();
            if(rrr.getMode() == RRR.Mode.REVISE) {
                RRRReviseScenario.getSingleton().drawEdgeList(g2);
                RRRReviseScenario.getSingleton().drawNodeList(g2);
            }
        }

        @Override
        public void getReady() {
        }

        @Override
        public void wrapUp() {
        }
    }
}
