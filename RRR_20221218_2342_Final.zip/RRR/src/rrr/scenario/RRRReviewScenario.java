package rrr.scenario;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import rrr.RRR;
import rrr.RRRScene;
import rrr.cmd.RRRCmdToChangeModeTo;
import rrr.cmd.RRRCmdToCreateCurPtCurve;
import rrr.cmd.RRRCmdToDeleteRecentQuestionPtCurve;
import x.XApp;
import x.XCmdToChangeScene;
import x.XScenario;

public class RRRReviewScenario extends XScenario {
    // singleton pattern
    private static RRRReviewScenario mSingleton = null;
    public static RRRReviewScenario createSingleton(XApp app) {
        assert(RRRReviewScenario.mSingleton == null);
        RRRReviewScenario.mSingleton = new RRRReviewScenario(app);
        return RRRReviewScenario.mSingleton;
    }
    public static RRRReviewScenario getSingleton() {
        assert(RRRReviewScenario.mSingleton != null);
        return RRRReviewScenario.mSingleton;
    }
    private RRRReviewScenario(XApp app) {
        super(app);
    }
    
    // methods
    @Override
    protected void addScenes() {
        this.addScene(RRRReviewScenario.ReviewReadyScene.createSingleton(this));
        this.addScene(
            RRRReviewScenario.QuestionWriteReadyScene.createSingleton(this));
    }

    public static class ReviewReadyScene extends RRRDefaultScenario.ReadyScene {
        // singleton pattern
        private static ReviewReadyScene mSingleton = null;
        public static ReviewReadyScene createSingleton(XScenario scenario) {
            assert(ReviewReadyScene.mSingleton == null);
            ReviewReadyScene.mSingleton = new ReviewReadyScene(scenario);
            return ReviewReadyScene.mSingleton;
        }
        public static ReviewReadyScene getSingleton() {
            assert(ReviewReadyScene.mSingleton != null);
            return ReviewReadyScene.mSingleton;
        }
        private ReviewReadyScene(XScenario scenario) {
            super(scenario);
        }

        @Override
        public void handleMousePress(MouseEvent e) {
            super.handleMousePress(e);
        }

        @Override
        public void handleMouseDrag(MouseEvent e) {
        }

        @Override
        public void handleMouseRelease(MouseEvent e) {
            
        }

        @Override
        public void handleKeyDown(KeyEvent e) {
            super.handleKeyDown(e);
            RRR rrr = (RRR)this.mScenario.getApp();
            int code = e.getKeyCode();
            switch(code) {
                case KeyEvent.VK_Q:
                    RRRCmdToChangeModeTo.execute(rrr, RRR.Mode.QUESTION);
                    
                    XCmdToChangeScene.execute(rrr, 
                        RRRReviewScenario.QuestionWriteReadyScene.getSingleton(), 
                        this);
                    break;
            }
        }

        @Override
        public void handleKeyUp(KeyEvent e) {
        }

        @Override
        public void updateSupportObjects() {
        }

        @Override
        public void renderWorldObjects(Graphics2D g2) {
        }

        @Override
        public void renderScreenObjects(Graphics2D g2) {
        }

        @Override
        public void getReady() {
        }

        @Override
        public void wrapUp() {
        }
    }
    
    public static class QuestionWriteReadyScene extends RRRScene {
        // singleton pattern
        private static QuestionWriteReadyScene mSingleton = null;
        public static QuestionWriteReadyScene createSingleton(
            XScenario scenario) {
            
            assert(QuestionWriteReadyScene.mSingleton == null);
            QuestionWriteReadyScene.mSingleton = 
                new QuestionWriteReadyScene(scenario);
            return QuestionWriteReadyScene.mSingleton;
        }
        public static QuestionWriteReadyScene getSingleton() {
            assert(QuestionWriteReadyScene.mSingleton != null);
            return QuestionWriteReadyScene.mSingleton;
        }
        private QuestionWriteReadyScene(XScenario scenario) {
            super(scenario);
        }

        @Override
        public void handleMousePress(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            Point pt = e.getPoint();
            RRRCmdToCreateCurPtCurve.execute(rrr, pt);
            
            XCmdToChangeScene.execute(rrr, 
                RRRDrawScenario.DrawScene.getSingleton(), this);
            
        }

        @Override
        public void handleMouseDrag(MouseEvent e) {
        }

        @Override
        public void handleMouseRelease(MouseEvent e) {
        }

        @Override
        public void handleKeyDown(KeyEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            int code = e.getKeyCode();
            switch(code) {
                case KeyEvent.VK_BACK_SPACE:
                    RRRCmdToDeleteRecentQuestionPtCurve.execute(rrr);
                    break; 
            }
        }

        @Override
        public void handleKeyUp(KeyEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            int code = e.getKeyCode();
            switch(code) {
                case KeyEvent.VK_Q:
                    RRRCmdToChangeModeTo.execute(rrr, RRR.Mode.REVIEW);
                    
                    XCmdToChangeScene.execute(rrr, 
                        RRRReviewScenario.ReviewReadyScene.getSingleton(), 
                        null);
                    break;
            }
        }

        @Override
        public void updateSupportObjects() {
        }

        @Override
        public void renderWorldObjects(Graphics2D g2) {
        }

        @Override
        public void renderScreenObjects(Graphics2D g2) {
        }

        @Override
        public void getReady() {
        }

        @Override
        public void wrapUp() {
        }
    }
}
