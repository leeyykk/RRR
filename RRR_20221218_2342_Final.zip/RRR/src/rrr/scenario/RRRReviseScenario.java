package rrr.scenario;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import rrr.RRR;
import rrr.RRRCanvas2D;
import rrr.RRREdge;
import rrr.RRRGraphObject;
import rrr.RRRNode;
import rrr.RRRScene;
import rrr.RRRUnderline;
import rrr.cmd.RRRCmdToAddCurUnderlineToUnderlineList;
import rrr.cmd.RRRCmdToChangeModeTo;
import rrr.cmd.RRRCmdToConnectNodesWithEdge;
import rrr.cmd.RRRCmdToCreateEdge;
import rrr.cmd.RRRCmdToCreateNode;
import rrr.cmd.RRRCmdToCreateUnderline;
import rrr.cmd.RRRCmdToDeleteSelectedEdge;
import rrr.cmd.RRRCmdToDeleteSelectedNode;
import rrr.cmd.RRRCmdToHighlightGraphObject;
import rrr.cmd.RRRCmdToSelectGraphObject;
import rrr.cmd.RRRCmdToSetEdgeNode;
import rrr.cmd.RRRCmdToSetStartingScreenPt;
import rrr.cmd.RRRCmdToTranslateNode;
import rrr.cmd.RRRCmdToUpdateUnderline;
import x.XApp;
import x.XCmdToChangeScene;
import x.XScenario;

public class RRRReviseScenario extends XScenario {
    // singleton pattern
    private static RRRReviseScenario mSingleton = null;
    public static RRRReviseScenario createSingleton(XApp app) {
        assert(RRRReviseScenario.mSingleton == null);
        RRRReviseScenario.mSingleton = new RRRReviseScenario(app);
        return RRRReviseScenario.mSingleton;
    }
    public static RRRReviseScenario getSingleton() {
        assert(RRRReviseScenario.mSingleton != null);
        return RRRReviseScenario.mSingleton;
    }
    private RRRReviseScenario(XApp app) {
        super(app);
    }
    
    // methods
    @Override
    protected void addScenes() {
        this.addScene(RRRReviseScenario.ReviseReadyScene.createSingleton(this));
        this.addScene(RRRReviseScenario.NodeCreateScene.createSingleton(this));
        this.addScene(RRRReviseScenario.EdgeCreateScene.createSingleton(this));
        this.addScene(RRRReviseScenario.NodePanScene.createSingleton(this));
        this.addScene(
            RRRReviseScenario.EdgeConnectionScene.createSingleton(this));
    }

    public static class ReviseReadyScene extends RRRDefaultScenario.ReadyScene {
        // singleton pattern
        private static ReviseReadyScene mSingleton = null;
        public static ReviseReadyScene createSingleton(XScenario scenario) {
            assert(ReviseReadyScene.mSingleton == null);
            ReviseReadyScene.mSingleton = new ReviseReadyScene(scenario);
            return ReviseReadyScene.mSingleton;
        }
        public static ReviseReadyScene getSingleton() {
            assert(ReviseReadyScene.mSingleton != null);
            return ReviseReadyScene.mSingleton;
        }
        private ReviseReadyScene(XScenario scenario) {
            super(scenario);
        }

        @Override
        public void handleMousePress(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            Point pt = e.getPoint();
            
            RRRNode node = RRRReviseScenario.getSingleton().
                findNodeByPt(pt);
            if(node != null) {
                RRRCmdToSelectGraphObject.execute(rrr, node);
                RRRCmdToHighlightGraphObject.execute(rrr, node, true);
                
                XCmdToChangeScene.execute(rrr, 
                    RRRReviseScenario.NodePanScene.getSingleton(), 
                    this);
                return;
            }
            
            RRREdge edge = RRRReviseScenario.getSingleton().findEdgeByPt(pt);
            if(edge != null) {
                RRRCmdToSelectGraphObject.execute(rrr, edge);
                RRRCmdToHighlightGraphObject.execute(rrr, edge, true);
                
                XCmdToChangeScene.execute(rrr, 
                    RRRReviseScenario.EdgeConnectionScene.getSingleton(), 
                    this);
            }
        }

        @Override
        public void handleMouseDrag(MouseEvent e) {
        }

        @Override
        public void handleMouseRelease(MouseEvent e) {
            
        }

        @Override
        public void handleKeyDown(KeyEvent e) {
            super.handleKeyDown(e);
            RRR rrr = (RRR)this.mScenario.getApp();
            int code = e.getKeyCode();

            switch(code) {
                case KeyEvent.VK_N:
                    RRRCmdToChangeModeTo.execute(rrr, RRR.Mode.EXTRACTNODE);
                    
                    XCmdToChangeScene.execute(rrr, 
                        RRRReviseScenario.NodeCreateScene.getSingleton(), 
                        this);
                    break;
                case KeyEvent.VK_E:
                    RRRCmdToChangeModeTo.execute(rrr, RRR.Mode.EXTRACTEDGE);
                    
                    XCmdToChangeScene.execute(rrr, 
                        RRRReviseScenario.EdgeCreateScene.getSingleton(), 
                        this);
                    break;
                case KeyEvent.VK_S:
                    RRRCmdToChangeModeTo.execute(rrr, RRR.Mode.RECORD);

                    XCmdToChangeScene.execute(rrr, 
                        RRRSelectScenario.SelectNoteReadyScene.getSingleton(), 
                        this);
                    break;
                
            }
        }

        @Override
        public void handleKeyUp(KeyEvent e) {
        }

        @Override
        public void updateSupportObjects() {
        }

        @Override
        public void renderWorldObjects(Graphics2D g2) {
        }

        @Override
        public void renderScreenObjects(Graphics2D g2) {
            RRRReviseScenario scenario = 
                (RRRReviseScenario)this.mScenario;
            scenario.drawEdgeList(g2);
            scenario.drawNodeList(g2);
        }

        @Override
        public void getReady() {
        }

        @Override
        public void wrapUp() {
        }
    }
    
    public static class NodeCreateScene extends RRRScene {
        // singleton pattern
        private static NodeCreateScene mSingleton = null;
        public static NodeCreateScene createSingleton(XScenario scenario) {
            assert(NodeCreateScene.mSingleton == null);
            NodeCreateScene.mSingleton = new NodeCreateScene(scenario);
            return NodeCreateScene.mSingleton;
        }
        public static NodeCreateScene getSingleton() {
            assert(NodeCreateScene.mSingleton != null);
            return NodeCreateScene.mSingleton;
        }
        private NodeCreateScene(XScenario scenario) {
            super(scenario);
        }

        @Override
        public void handleMousePress(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            Point pt = e.getPoint();
            RRRCmdToCreateUnderline.execute(rrr, pt);
        }

        @Override
        public void handleMouseDrag(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            Point pt = e.getPoint();
            RRRCmdToUpdateUnderline.execute(rrr, pt);
        }

        @Override
        public void handleMouseRelease(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            RRRCmdToAddCurUnderlineToUnderlineList.execute(rrr);
        }
        
        @Override
        public void handleKeyDown(KeyEvent e) {
        }

        @Override
        public void handleKeyUp(KeyEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            int code = e.getKeyCode();
            switch(code) {
                case KeyEvent.VK_N:
                    RRRCmdToAddCurUnderlineToUnderlineList.execute(rrr);
                    RRRCmdToCreateNode.execute(rrr);
                    RRRCmdToChangeModeTo.execute(rrr, RRR.Mode.REVISE);
                    
                    XCmdToChangeScene.execute(rrr, 
                        RRRReviseScenario.ReviseReadyScene.getSingleton(), 
                        this);
                    break;
            }
        }

        @Override
        public void updateSupportObjects() {
        }

        @Override
        public void renderWorldObjects(Graphics2D g2) {
        }

        @Override
        public void renderScreenObjects(Graphics2D g2) {
            RRRReviseScenario scenario = 
                (RRRReviseScenario)this.mScenario;
            scenario.drawCurUnderline(g2);
            scenario.drawUnderlineList(g2);
        }

        @Override
        public void getReady() {
        }

        @Override
        public void wrapUp() {
        }
    }
    
    public static class EdgeCreateScene extends RRRScene {
        // singleton pattern
        private static EdgeCreateScene mSingleton = null;
        public static EdgeCreateScene createSingleton(XScenario scenario) {
            assert(EdgeCreateScene.mSingleton == null);
            EdgeCreateScene.mSingleton = new EdgeCreateScene(scenario);
            return EdgeCreateScene.mSingleton;
        }
        public static EdgeCreateScene getSingleton() {
            assert(EdgeCreateScene.mSingleton != null);
            return EdgeCreateScene.mSingleton;
        }
        private EdgeCreateScene(XScenario scenario) {
            super(scenario);
        }
        
        @Override
        public void handleMousePress(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            Point pt = e.getPoint();
            RRRCmdToCreateUnderline.execute(rrr, pt);
        }

        @Override
        public void handleMouseDrag(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            Point pt = e.getPoint();
            RRRCmdToUpdateUnderline.execute(rrr, pt);
        }

        @Override
        public void handleMouseRelease(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            RRRCmdToAddCurUnderlineToUnderlineList.execute(rrr);
        }
        
        @Override
        public void handleKeyDown(KeyEvent e) {
        }

        @Override
        public void handleKeyUp(KeyEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            int code = e.getKeyCode();
            switch(code) {
                case KeyEvent.VK_E:
                    RRRCmdToAddCurUnderlineToUnderlineList.execute(rrr);
                    RRRCmdToCreateEdge.execute(rrr);
                    RRRCmdToChangeModeTo.execute(rrr, RRR.Mode.REVISE);
                    
                    XCmdToChangeScene.execute(rrr, 
                        RRRReviseScenario.ReviseReadyScene.getSingleton(), 
                        this);
                    break;
            }
        }

        @Override
        public void updateSupportObjects() {
        }

        @Override
        public void renderWorldObjects(Graphics2D g2) {
        }

        @Override
        public void renderScreenObjects(Graphics2D g2) {
            RRRReviseScenario scenario = 
                (RRRReviseScenario)this.mScenario;
            scenario.drawCurUnderline(g2);
            scenario.drawUnderlineList(g2);
        }

        @Override
        public void getReady() {
        }

        @Override
        public void wrapUp() {
        }
    }
    
    public static class NodePanScene extends RRRScene {
        // singleton pattern
        private static NodePanScene mSingleton = null;
        public static NodePanScene createSingleton(XScenario scenario) {
            assert(NodePanScene.mSingleton == null);
            NodePanScene.mSingleton = new NodePanScene(scenario);
            return NodePanScene.mSingleton;
        }
        public static NodePanScene getSingleton() {
            assert(NodePanScene.mSingleton != null);
            return NodePanScene.mSingleton;
        }
        private NodePanScene(XScenario scenario) {
            super(scenario);
        }

        @Override
        public void handleMousePress(MouseEvent e) {
        }

        @Override
        public void handleMouseDrag(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            Point pt = e.getPoint();
            RRRCmdToTranslateNode.execute(rrr, pt);
        }

        @Override
        public void handleMouseRelease(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            RRRNode node = (RRRNode) RRRReviseScenario.getSingleton().
                getSelectedGraphObject();
            RRRCmdToHighlightGraphObject.execute(rrr, node, false);
            RRRCmdToSetStartingScreenPt.execute(rrr, null);
            
            XCmdToChangeScene.execute(rrr, 
                RRRReviseScenario.ReviseReadyScene.getSingleton(), 
                this.mReturnScene);
        }

        @Override
        public void handleKeyDown(KeyEvent e) {
        }

        @Override
        public void handleKeyUp(KeyEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            int code = e.getKeyCode();
            switch(code) {
                case KeyEvent.VK_BACK_SPACE:
                    RRRCmdToDeleteSelectedNode.execute(rrr);
                    
                    XCmdToChangeScene.execute(rrr, 
                        RRRReviseScenario.ReviseReadyScene.getSingleton(), 
                        this);
                    break;
            }
        }

        @Override
        public void updateSupportObjects() {
        }

        @Override
        public void renderWorldObjects(Graphics2D g2) {
        }

        @Override
        public void renderScreenObjects(Graphics2D g2) {
            RRRReviseScenario scenario = 
                (RRRReviseScenario)this.mScenario;
            scenario.drawEdgeList(g2);
            scenario.drawNodeList(g2);
        }

        @Override
        public void getReady() {
        }

        @Override
        public void wrapUp() {
        }
    }
    
    public static class EdgeConnectionScene extends RRRScene {
        // singleton pattern
        private static EdgeConnectionScene mSingleton = null;
        public static EdgeConnectionScene createSingleton(XScenario scenario) {
            assert(EdgeConnectionScene.mSingleton == null);
            EdgeConnectionScene.mSingleton = new EdgeConnectionScene(scenario);
            return EdgeConnectionScene.mSingleton;
        }        
        public static EdgeConnectionScene getSingleton() {
            assert(EdgeConnectionScene.mSingleton != null);
            return EdgeConnectionScene.mSingleton;
        }
        private EdgeConnectionScene(XScenario scenario) {
            super(scenario);
        }

        @Override
        public void handleMousePress(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            Point pt = e.getPoint();
            
            RRREdge selectedEdge = (RRREdge)RRRReviseScenario.
                getSingleton().getSelectedGraphObject();
            
            RRRNode node = RRRReviseScenario.getSingleton().findNodeByPt(pt);
            if(node != null) {
                RRRCmdToHighlightGraphObject.execute(rrr, node, true);
                
                if(RRRReviseScenario.getSingleton().getFirstNode() == null) {
                    RRRCmdToSetEdgeNode.execute(rrr, node, 1);
                } else {
                    if(node != RRRReviseScenario.getSingleton().getFirstNode() && 
                        RRRReviseScenario.getSingleton().getSecondNode() == null) {
                        
                        RRRCmdToSetEdgeNode.execute(rrr, node, 2);
                        RRRCmdToConnectNodesWithEdge.execute(rrr, 
                            RRRReviseScenario.getSingleton().getFirstNode(),
                            RRRReviseScenario.getSingleton().getSecondNode(), 
                            selectedEdge);
                        
                        XCmdToChangeScene.execute(rrr, 
                            RRRReviseScenario.ReviseReadyScene.getSingleton(), 
                            this.mReturnScene);
                    }
                }
            }
        }

        @Override
        public void handleMouseDrag(MouseEvent e) {
            
        }

        @Override
        public void handleMouseRelease(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            RRRNode firstNode = RRRReviseScenario.getSingleton().
                getFirstNode();
            RRRNode secondNode = RRRReviseScenario.getSingleton().
                getSecondNode();
            if(firstNode != null && secondNode != null) {
                RRREdge edge = (RRREdge)RRRReviseScenario.getSingleton().
                    getSelectedGraphObject();
                RRRCmdToHighlightGraphObject.execute(rrr, firstNode, false);
                RRRCmdToHighlightGraphObject.execute(rrr, secondNode, false);
                RRRCmdToHighlightGraphObject.execute(rrr, edge, false);

                XCmdToChangeScene.execute(rrr, 
                    RRRReviseScenario.ReviseReadyScene.getSingleton(), 
                    this.mReturnScene);
            }  
        }

        @Override
        public void handleKeyDown(KeyEvent e) {
        }

        @Override
        public void handleKeyUp(KeyEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            int code = e.getKeyCode();
            switch(code) {
                case KeyEvent.VK_ESCAPE:
                    RRRNode firstNode = RRRReviseScenario.getSingleton().
                        getFirstNode();
                    RRRNode secondNode = RRRReviseScenario.getSingleton().
                        getSecondNode();
                    RRREdge edge = (RRREdge) RRRReviseScenario.getSingleton().
                        getSelectedGraphObject();
                    
                    RRRCmdToHighlightGraphObject.execute(rrr, firstNode, false);
                    RRRCmdToHighlightGraphObject.execute(rrr, secondNode, false);
                    RRRCmdToHighlightGraphObject.execute(rrr, edge, false);
                    
                    RRRCmdToSetEdgeNode.execute(rrr, null, 1);
                    RRRCmdToSetEdgeNode.execute(rrr, null, 2);
                    
                    RRRCmdToSelectGraphObject.execute(rrr, null);
                    
                    XCmdToChangeScene.execute(rrr, 
                        RRRReviseScenario.ReviseReadyScene.getSingleton(), 
                        null);
                    break;
                case KeyEvent.VK_BACK_SPACE:
                    RRRCmdToDeleteSelectedEdge.execute(rrr);
                    
                    XCmdToChangeScene.execute(rrr, 
                        RRRReviseScenario.ReviseReadyScene.getSingleton(), 
                        this);
                    break;
            }
        }

        @Override
        public void updateSupportObjects() {
        }

        @Override
        public void renderWorldObjects(Graphics2D g2) {
        }

        @Override
        public void renderScreenObjects(Graphics2D g2) {
            RRRReviseScenario scenario = 
                (RRRReviseScenario)this.mScenario;
            scenario.drawEdgeList(g2);
            scenario.drawNodeList(g2);
        }

        @Override
        public void getReady() {
        }

        @Override
        public void wrapUp() {
        }
    }
    
    private RRRUnderline mCurUnderline = null;
    public RRRUnderline getCurUnderline() {
        return this.mCurUnderline;
    }
    public void setCurUnderline(RRRUnderline underline) {
        this.mCurUnderline = underline;
    }
    
    private ArrayList<RRRUnderline> mUnderlineList = 
        new ArrayList<RRRUnderline>();
    public ArrayList<RRRUnderline> getUnderlineList() {
        return this.mUnderlineList;
    }
    
    private ArrayList<RRRNode> mNodeList = new ArrayList<RRRNode>();
    public ArrayList<RRRNode> getNodeList() {
        return this.mNodeList;
    }
    
    private ArrayList<RRREdge> mEdgeList = new ArrayList<RRREdge>();
    public ArrayList<RRREdge> getEdgeList() {
        return this.mEdgeList;
    }
    
    private RRRGraphObject mSelectedGraphObject = null;
    public RRRGraphObject getSelectedGraphObject() {
        return this.mSelectedGraphObject;
    }
    public void setSelectedGraphObject(RRRGraphObject object) {
        this.mSelectedGraphObject = object;
        if(object != null) {
            this.mSelectedGraphObject.setIsHighlighted(true);
        }
    }
    
    private RRRNode mFirstNode = null;
    public RRRNode getFirstNode() {
        return this.mFirstNode;
    }
    public void setFirstNode(RRRNode node) {
        this.mFirstNode = node;
    }
    private RRRNode mSecondNode = null;
    public RRRNode getSecondNode() {
        return this.mSecondNode;
    }
    public void setSecondNode(RRRNode node) {
        this.mSecondNode = node;
    }
    
    private void drawCurUnderline(Graphics2D g2) {
        if(this.getCurUnderline() != null) {
            g2.setColor(RRRCanvas2D.COLOR_SELECTION_BOX);
            g2.setStroke(RRRCanvas2D.STROKE_SELECTION_BOX);
            g2.draw(this.getCurUnderline());
        }
    }
    
    private void drawUnderlineList(Graphics2D g2) {
        for(RRRUnderline underline : this.mUnderlineList) {
            g2.setColor(RRRCanvas2D.COLOR_SELECTION_BOX);
            g2.setStroke(RRRCanvas2D.STROKE_SELECTION_BOX);
            g2.draw(underline);
        }
    }
    
    public void drawNodeList(Graphics2D g2) {
        for(RRRNode node : this.mNodeList) {
            g2.setColor(RRRCanvas2D.COLOR_NODE);
            g2.setStroke(RRRCanvas2D.STROKE_NODE);
            if(node.getIsHighlighted()) {
                g2.setColor(RRRCanvas2D.COLOR_SELECTED_OBJECT);
            }
            
            Ellipse2D ellipse = new Ellipse2D.Double(
                node.getCenter().x - node.getNodeDiameter() / 2, 
                node.getCenter().y - node.getNodeDiameter() / 2, 
                node.getNodeDiameter(), 
                node.getNodeDiameter());
            g2.fill(ellipse);
            g2.drawImage(node.getImage(), 
                (int)ellipse.getCenterX() - node.getImage().getWidth() / 2, 
                (int)ellipse.getCenterY() - node.getImage().getHeight() / 2, 
                null);
//            g2.draw(node.getBounds2D());
        }
    }
    
    public void drawEdgeList(Graphics2D g2) {
        for(RRREdge edge : this.mEdgeList) {
            g2.setStroke(RRRCanvas2D.STROKE_EDGE);
            if(edge.getIsHighlighted()) {
                g2.setColor(RRRCanvas2D.COLOR_EDGE_HIGHLIGHT);
                Rectangle2D boundary = edge.getBounds2D();
                g2.draw(boundary);
            }
            g2.setColor(RRRCanvas2D.COLOR_EDGE);
            RRRNode firstNode = edge.getFirstNode();
            RRRNode secondNode = edge.getSecondNode();
            if(firstNode != null && secondNode != null) {
                Line2D line = new Line2D.Double(
                    firstNode.getCenter().x, firstNode.getCenter().y,
                    secondNode.getCenter().x, secondNode.getCenter().y);
                g2.draw(line);
            } 
            g2.drawImage(edge.getImage(), 
                (int)(edge.getStartPt().x + edge.getEndPt().x) / 2 - 
                    edge.getImage().getWidth() / 2, 
                (int)(edge.getStartPt().y + edge.getEndPt().y) / 2 - 
                    edge.getImage().getHeight() / 2, 
                null);
//            g2.draw(edge.getBounds2D());
        }
    }
    
    private RRRNode findNodeByPt(Point pt) {
        ArrayList<RRRNode> nodeList = 
            RRRReviseScenario.getSingleton().getNodeList();
        for(RRRNode node : nodeList) {
            if(node.getBounds2D().contains(pt)) {
                return node;
            }
        }
        return null;
    }
    
    private RRREdge findEdgeByPt(Point pt) {
        ArrayList<RRREdge> edgeList = 
            RRRReviseScenario.getSingleton().getEdgeList();
        for(RRREdge edge : edgeList) {
            if(edge.getBounds2D().contains(pt)) {
                return edge;
            }
        }
        return null;
    }
}
