package rrr.scenario;

import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import rrr.RRR;
import rrr.cmd.RRRCmdToChangeModeTo;
import x.XApp;
import x.XCmdToChangeScene;
import x.XScenario;

public class RRRRecordScenario extends XScenario {
    // singleton pattern
    private static RRRRecordScenario mSingleton = null;
    public static RRRRecordScenario createSingleton(XApp app) {
        assert(RRRRecordScenario.mSingleton == null);
        RRRRecordScenario.mSingleton = new RRRRecordScenario(app);
        return RRRRecordScenario.mSingleton;
    }
    public static RRRRecordScenario getSingleton() {
        assert(RRRRecordScenario.mSingleton != null);
        return RRRRecordScenario.mSingleton;
    }
    private RRRRecordScenario(XApp app) {
        super(app);
    }
    
    // methods
    @Override
    protected void addScenes() {
        this.addScene(RRRRecordScenario.RecordReadyScene.createSingleton(this));
    }

    public static class RecordReadyScene extends RRRDefaultScenario.ReadyScene {
        // singleton pattern
        private static RecordReadyScene mSingleton = null;
        public static RecordReadyScene createSingleton(XScenario scenario) {
            assert(RecordReadyScene.mSingleton == null);
            RecordReadyScene.mSingleton = new RecordReadyScene(scenario);
            return RecordReadyScene.mSingleton;
        }
        public static RecordReadyScene getSingleton() {
            assert(RecordReadyScene.mSingleton != null);
            return RecordReadyScene.mSingleton;
        }
        private RecordReadyScene(XScenario scenario) {
            super(scenario);
        }

        @Override
        public void handleMousePress(MouseEvent e) {
            super.handleMousePress(e);
        }

        @Override
        public void handleMouseDrag(MouseEvent e) {
        }

        @Override
        public void handleMouseRelease(MouseEvent e) {
        }

        @Override
        public void handleKeyDown(KeyEvent e) {
            super.handleKeyDown(e);
            RRR rrr = (RRR)this.mScenario.getApp();
            int code = e.getKeyCode();
            switch(code) {
                case KeyEvent.VK_Q:
                    RRRCmdToChangeModeTo.execute(rrr, RRR.Mode.QUESTION);
                    
                    XCmdToChangeScene.execute(rrr, 
                        RRRSelectScenario.SelectReadyScene.getSingleton(), 
                        this);
                    break;
            }
        }

        @Override
        public void handleKeyUp(KeyEvent e) {
        }

        @Override
        public void updateSupportObjects() {
        }

        @Override
        public void renderWorldObjects(Graphics2D g2) {
        }

        @Override
        public void renderScreenObjects(Graphics2D g2) {
        }

        @Override
        public void getReady() {
        }

        @Override
        public void wrapUp() {
        }
    }
}
    
