package rrr.scenario;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import rrr.RRR;
import rrr.RRRScene;
import rrr.cmd.RRRCmdToAddCurPtCurveToPtCurves;
import rrr.cmd.RRRCmdToChangeModeTo;
import rrr.cmd.RRRCmdToUpdateCurPtCurve;
import x.XApp;
import x.XCmdToChangeScene;
import x.XScenario;

public class RRRDrawScenario extends XScenario {
    // singleton pattern
    private static RRRDrawScenario mSingleton = null;
    public static RRRDrawScenario createSingleton(XApp app) {
        assert(RRRDrawScenario.mSingleton == null);
        RRRDrawScenario.mSingleton = new RRRDrawScenario(app);
        return RRRDrawScenario.mSingleton;
    }
    public static RRRDrawScenario getSingleton() {
        assert(RRRDrawScenario.mSingleton != null);
        return RRRDrawScenario.mSingleton;
    }
    private RRRDrawScenario(XApp app) {
        super(app);
    }
    
    // methods
    @Override
    protected void addScenes() {
        this.addScene(RRRDrawScenario.DrawScene.createSingleton(this));
    }

    public static class DrawScene extends RRRScene {
        // singleton pattern
        private static DrawScene mSingleton = null;
        public static DrawScene createSingleton(XScenario scenario) {
            assert(DrawScene.mSingleton == null);
            DrawScene.mSingleton = new DrawScene(scenario);
            return DrawScene.mSingleton;
        }
        public static DrawScene getSingleton() {
            assert(DrawScene.mSingleton != null);
            return DrawScene.mSingleton;
        }
        private DrawScene(XScenario scenario) {
            super(scenario);
        }

        @Override
        public void handleMousePress(MouseEvent e) {
        }

        @Override
        public void handleMouseDrag(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            Point pt = e.getPoint();
            RRRCmdToUpdateCurPtCurve.execute(rrr, pt);
        }

        @Override
        public void handleMouseRelease(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            RRRCmdToAddCurPtCurveToPtCurves.execute(rrr);

            XCmdToChangeScene.execute(rrr, this.mReturnScene, null);
        }

        @Override
        public void handleKeyDown(KeyEvent e) {
        }

        @Override
        public void handleKeyUp(KeyEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            int code = e.getKeyCode();
            switch(code) {
                case KeyEvent.VK_Q:
                    if(rrr.getMode() == RRR.Mode.QUESTION) {
                        RRRCmdToAddCurPtCurveToPtCurves.execute(rrr);
                        RRRCmdToChangeModeTo.execute(rrr, RRR.Mode.REVIEW);
                        
                        XCmdToChangeScene.execute(rrr, 
                            RRRReviewScenario.ReviewReadyScene.getSingleton(), 
                            null);
                    }
                    break;
            }
        }

        @Override
        public void updateSupportObjects() {
        }

        @Override
        public void renderWorldObjects(Graphics2D g2) {
        }

        @Override
        public void renderScreenObjects(Graphics2D g2) {
        }

        @Override
        public void getReady() {
        }

        @Override
        public void wrapUp() {
        }
    }
}
