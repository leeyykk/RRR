package rrr.scenario;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Shape;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import rrr.RRR;
import rrr.RRRCanvas2D;
import rrr.RRRPtCurve;
import rrr.RRRPtCurveMgr;
import rrr.RRRScene;
import rrr.RRRSelectionBox;
import rrr.cmd.RRRCmdToAddSelectedPtCurvesToRevisePtCurves;
import rrr.cmd.RRRCmdToChangeModeTo;
import rrr.cmd.RRRCmdToCreateSelectionBox;
import rrr.cmd.RRRCmdToDeleteSelectedPtCurves;
import rrr.cmd.RRRCmdToDeselectSelectedPtCurves;
import rrr.cmd.RRRCmdToDestroySelectionBox;
import rrr.cmd.RRRCmdToUpdateSelectedPtCurves;
import rrr.cmd.RRRCmdToUpdateSelectionBox;
import rrr.cmd.RRRCmdToUpdateSelectedRecordPtCurves;
import x.XApp;
import x.XCmdToChangeScene;
import x.XScenario;

public class RRRSelectScenario extends XScenario {
    // singleton pattern
    private static RRRSelectScenario mSingleton = null;
    public static RRRSelectScenario createSingleton(XApp app) {
        assert(RRRSelectScenario.mSingleton == null);
        RRRSelectScenario.mSingleton = new RRRSelectScenario(app);
        return RRRSelectScenario.mSingleton;
    }
    public static RRRSelectScenario getSingleton() {
        assert(RRRSelectScenario.mSingleton != null);
        return RRRSelectScenario.mSingleton;
    }
    private RRRSelectScenario(XApp app) {
        super(app);
    }
    
    // methods
    @Override
    protected void addScenes() {
        this.addScene(RRRSelectScenario.SelectReadyScene.createSingleton(this));
        this.addScene(RRRSelectScenario.SelectScene.createSingleton(this));
        this.addScene(
            RRRSelectScenario.SelectedReadyScene.createSingleton(this));
        this.addScene(
            RRRSelectScenario.SelectNoteReadyScene.createSingleton(this));
        this.addScene(RRRSelectScenario.SelectNoteScene.createSingleton(this));
    }

    public static class SelectReadyScene extends RRRScene {
        // singleton pattern
        private static SelectReadyScene mSingleton = null;
        public static SelectReadyScene createSingleton(XScenario scenario) {
            assert(SelectReadyScene.mSingleton == null);
            SelectReadyScene.mSingleton = new SelectReadyScene(scenario);
            return SelectReadyScene.mSingleton;
        }
        public static SelectReadyScene getSingleton() {
            assert(SelectReadyScene.mSingleton != null);
            return SelectReadyScene.mSingleton;
        }
        private SelectReadyScene(XScenario scenario) {
            super(scenario);
        }

        @Override
        public void handleMousePress(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            Point pt = e.getPoint();
            RRRCmdToCreateSelectionBox.execute(rrr, pt);
            
            XCmdToChangeScene.execute(rrr, 
                RRRSelectScenario.SelectScene.getSingleton(), this);
        }

        @Override
        public void handleMouseDrag(MouseEvent e) {
        }

        @Override
        public void handleMouseRelease(MouseEvent e) {
        }

        @Override
        public void handleKeyDown(KeyEvent e) {
        }

        @Override
        public void handleKeyUp(KeyEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            RRRPtCurveMgr ptCurveMgr = rrr.getPtCurveMgr();
            int code = e.getKeyCode();
            switch(code) {
                case KeyEvent.VK_SHIFT:
                    if(rrr.getMode() == RRR.Mode.QUESTION) {
                        break;
                    }

                    RRRCmdToDestroySelectionBox.execute(rrr);
                    
                    if(ptCurveMgr.getSelectedPtCurves().isEmpty()) {
                        if(rrr.getMode() == RRR.Mode.REVIEW) {
                            XCmdToChangeScene.execute(rrr, 
                                RRRReviewScenario.ReviewReadyScene.getSingleton(), 
                                null);
                        } else if(rrr.getMode() == RRR.Mode.RECORD) {
                            XCmdToChangeScene.execute(rrr, 
                                RRRRecordScenario.RecordReadyScene.getSingleton(), 
                                null);
                        } else if(rrr.getMode() == RRR.Mode.REVISE) {
                            XCmdToChangeScene.execute(rrr, 
                                RRRReviseScenario.ReviseReadyScene.getSingleton(), 
                                null);
                        } else {
                            XCmdToChangeScene.execute(rrr, 
                                RRRDefaultScenario.ReadyScene.getSingleton(), 
                                null);
                        }
                    } else {
                        if(rrr.getMode() == RRR.Mode.REVISE) {
                            XCmdToChangeScene.execute(rrr, 
                                RRRNavigateScenario.PanReadyScene.getSingleton(), 
                                this.mReturnScene);
                        } else {
                            XCmdToChangeScene.execute(rrr, 
                                RRRSelectScenario.SelectedReadyScene.getSingleton(), 
                                null);
                        }
                    }
                    break;
                case KeyEvent.VK_Q:
                    RRRCmdToDestroySelectionBox.execute(rrr);
                    RRRCmdToChangeModeTo.execute(rrr, RRR.Mode.RECORD);
                    
                    XCmdToChangeScene.execute(rrr, 
                        RRRRecordScenario.RecordReadyScene.getSingleton(), 
                        null);
                    break;
            }
        }

        @Override
        public void updateSupportObjects() {
        }

        @Override
        public void renderWorldObjects(Graphics2D g2) {
        }

        @Override
        public void renderScreenObjects(Graphics2D g2) {
            RRR rrr = (RRR)this.mScenario.getApp();
            if(rrr.getMode() == RRR.Mode.REVISE) {
                RRRReviseScenario.getSingleton().drawEdgeList(g2);
                RRRReviseScenario.getSingleton().drawNodeList(g2);
            }
            
        }

        @Override
        public void getReady() {
        }

        @Override
        public void wrapUp() {
        }
    }
    
    public static class SelectScene extends RRRScene {
        // singleton pattern
        private static SelectScene mSingleton = null;
        public static SelectScene createSingleton(XScenario scenario) {
            assert(SelectScene.mSingleton == null);
            SelectScene.mSingleton = new SelectScene(scenario);
            return SelectScene.mSingleton;
        }
        public static SelectScene getSingleton() {
            assert(SelectScene.mSingleton != null);
            return SelectScene.mSingleton;
        }
        private SelectScene(XScenario scenario) {
            super(scenario);
        }

        @Override
        public void handleMousePress(MouseEvent e) {
        }

        @Override
        public void handleMouseDrag(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            Point pt = e.getPoint();
            RRRCmdToUpdateSelectionBox.execute(rrr, pt);
            RRRCmdToUpdateSelectedPtCurves.execute(rrr);
        }

        @Override
        public void handleMouseRelease(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            RRRCmdToDestroySelectionBox.execute(rrr);

            if(rrr.getMode() == RRR.Mode.QUESTION) {
                RRRCmdToDeleteSelectedPtCurves.execute(rrr);
            }
            
            XCmdToChangeScene.execute(rrr, 
                RRRSelectScenario.SelectReadyScene.getSingleton(), 
                this.mReturnScene);
        }

        @Override
        public void handleKeyDown(KeyEvent e) {
        }

        @Override
        public void handleKeyUp(KeyEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            RRRPtCurveMgr ptCurveMgr = rrr.getPtCurveMgr();
            int code = e.getKeyCode();
            switch(code) {
                case KeyEvent.VK_SHIFT:
                    if(rrr.getMode() == RRR.Mode.QUESTION) {
                        break;
                    }
                    
                    RRRCmdToDestroySelectionBox.execute(rrr);
                    
                    if(ptCurveMgr.getSelectedPtCurves().isEmpty()) {
                        if(rrr.getMode() == RRR.Mode.REVIEW) {
                            XCmdToChangeScene.execute(rrr, 
                                RRRReviewScenario.ReviewReadyScene.getSingleton(), 
                                null);
                        } else if(rrr.getMode() == RRR.Mode.RECORD) {
                            XCmdToChangeScene.execute(rrr, 
                                RRRRecordScenario.RecordReadyScene.getSingleton(), 
                                null);
                        } else if(rrr.getMode() == RRR.Mode.REVISE) {
                            XCmdToChangeScene.execute(rrr, 
                                RRRReviseScenario.ReviseReadyScene.getSingleton(), 
                                null);
                        } else {
                            XCmdToChangeScene.execute(rrr, 
                                RRRDefaultScenario.ReadyScene.getSingleton(), 
                                null);
                        }
                    } else {
                        if(rrr.getMode() == RRR.Mode.REVISE) {
                            XCmdToChangeScene.execute(rrr, 
                                RRRNavigateScenario.PanReadyScene.getSingleton(), 
                                this.mReturnScene);
                        } else {
                            XCmdToChangeScene.execute(rrr, 
                                RRRSelectScenario.SelectedReadyScene.getSingleton(), 
                                null);
                        }
                    }
                    break;
                case KeyEvent.VK_Q:
                    RRRCmdToDestroySelectionBox.execute(rrr);
                    RRRCmdToChangeModeTo.execute(rrr, RRR.Mode.RECORD);

                    XCmdToChangeScene.execute(rrr, 
                        RRRRecordScenario.RecordReadyScene.getSingleton(), 
                        null);
                    break;
                case KeyEvent.VK_S:
                    RRRCmdToDestroySelectionBox.execute(rrr);
                    RRRCmdToAddSelectedPtCurvesToRevisePtCurves.execute(rrr);
                    RRRCmdToChangeModeTo.execute(rrr, RRR.Mode.REVISE);
                    
                    XCmdToChangeScene.execute(rrr, 
                        RRRReviseScenario.ReviseReadyScene.getSingleton(), 
                        null);
                    break;
            }
        }

        @Override
        public void updateSupportObjects() {
        }

        @Override
        public void renderWorldObjects(Graphics2D g2) {
        }

        @Override
        public void renderScreenObjects(Graphics2D g2) {
            RRRSelectScenario scenario = (RRRSelectScenario) this.mScenario;
            scenario.drawSelectionBox(g2);
           
            RRR rrr = (RRR)this.mScenario.getApp();
            if(rrr.getMode() == RRR.Mode.REVISE) {
                RRRReviseScenario.getSingleton().drawEdgeList(g2);
                RRRReviseScenario.getSingleton().drawNodeList(g2);
            }
            
        }

        @Override
        public void getReady() {
        }

        @Override
        public void wrapUp() {
        }
    }
    
    public static class SelectedReadyScene extends RRRScene {
        // singleton pattern
        private static SelectedReadyScene mSingleton = null;
        public static SelectedReadyScene createSingleton(XScenario scenario) {
            assert(SelectedReadyScene.mSingleton == null);
            SelectedReadyScene.mSingleton = new SelectedReadyScene(scenario);
            return SelectedReadyScene.mSingleton;
        }
        public static SelectedReadyScene getSingleton() {
            assert(SelectedReadyScene.mSingleton != null);
            return SelectedReadyScene.mSingleton;
        }
        private SelectedReadyScene(XScenario scenario) {
            super(scenario);
        }

        @Override
        public void handleMousePress(MouseEvent e) {
        }

        @Override
        public void handleMouseDrag(MouseEvent e) {
        }

        @Override
        public void handleMouseRelease(MouseEvent e) {
        }

        @Override
        public void handleKeyDown(KeyEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            int code = e.getKeyCode();
            switch(code) {
                case KeyEvent.VK_SHIFT:
                    XCmdToChangeScene.execute(rrr, 
                        RRRSelectScenario.SelectReadyScene.getSingleton(), 
                        this);
                    break;  
                case KeyEvent.VK_CONTROL:
                    XCmdToChangeScene.execute(rrr, 
                        RRRNavigateScenario.PanReadyScene.getSingleton(), null);
                    break;
                case KeyEvent.VK_ALT:
                    XCmdToChangeScene.execute(rrr, 
                        RRRNavigateScenario.ZoomRotateReadyScene.getSingleton(), 
                        null);
                    break;
                case KeyEvent.VK_Q:
                    RRRCmdToDeselectSelectedPtCurves.execute(rrr);
                    RRRCmdToChangeModeTo.execute(rrr, RRR.Mode.QUESTION);
                    
                    XCmdToChangeScene.execute(rrr, 
                        RRRReviewScenario.QuestionWriteReadyScene.getSingleton(), 
                        null);
                    break;
            }
        }

        @Override
        public void handleKeyUp(KeyEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            int code = e.getKeyCode();
            switch(code) {
                case KeyEvent.VK_ESCAPE:
                    RRRCmdToDeselectSelectedPtCurves.execute(rrr);
                    
                    if(rrr.getMode() == RRR.Mode.REVIEW) {
                        XCmdToChangeScene.execute(rrr, 
                            RRRReviewScenario.ReviewReadyScene.getSingleton(), 
                            null);
                    } else if(rrr.getMode() == RRR.Mode.RECORD) {
                        XCmdToChangeScene.execute(rrr, 
                            RRRRecordScenario.RecordReadyScene.getSingleton(), 
                            null);
                    } else {
                        XCmdToChangeScene.execute(rrr, 
                            RRRDefaultScenario.ReadyScene.getSingleton(), null);
                    }
                    break;
                case KeyEvent.VK_BACK_SPACE:
                    RRRCmdToDeleteSelectedPtCurves.execute(rrr);
                    
                    if(rrr.getMode() == RRR.Mode.REVIEW) {
                        XCmdToChangeScene.execute(rrr, 
                            RRRReviewScenario.ReviewReadyScene.getSingleton(), 
                            null);
                    } else if(rrr.getMode() == RRR.Mode.RECORD) {
                        XCmdToChangeScene.execute(rrr, 
                            RRRRecordScenario.RecordReadyScene.getSingleton(), 
                            null);
                    } else {
                        XCmdToChangeScene.execute(rrr, 
                            RRRDefaultScenario.ReadyScene.getSingleton(), null);
                    }
                    break;
            }
        }

        @Override
        public void updateSupportObjects() {
        }

        @Override
        public void renderWorldObjects(Graphics2D g2) {
        }

        @Override
        public void renderScreenObjects(Graphics2D g2) {
            RRR rrr = (RRR)this.mScenario.getApp();            
            if(rrr.getMode() == RRR.Mode.REVISE) {
                RRRReviseScenario.getSingleton().drawEdgeList(g2);
                RRRReviseScenario.getSingleton().drawNodeList(g2);
            }
        }

        @Override
        public void getReady() {
        }

        @Override
        public void wrapUp() {
        }
    }
    
    public static class SelectNoteReadyScene extends RRRScene {
        // singleton pattern
        private static SelectNoteReadyScene mSingleton = null;
        public static SelectNoteReadyScene createSingleton(XScenario scenario) {
            assert(SelectNoteReadyScene.mSingleton == null);
            SelectNoteReadyScene.mSingleton = new SelectNoteReadyScene(scenario);
            return SelectNoteReadyScene.mSingleton;
        }
        public static SelectNoteReadyScene getSingleton() {
            assert(SelectNoteReadyScene.mSingleton != null);
            return SelectNoteReadyScene.mSingleton;
        }
        private SelectNoteReadyScene(XScenario scenario) {
            super(scenario);
        }

        @Override
        public void handleMousePress(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            Point pt = e.getPoint();
            RRRCmdToCreateSelectionBox.execute(rrr, pt);
            
            XCmdToChangeScene.execute(rrr, 
                RRRSelectScenario.SelectNoteScene.getSingleton(), this);
        }

        @Override
        public void handleMouseDrag(MouseEvent e) {
            
        }

        @Override
        public void handleMouseRelease(MouseEvent e) {
        }

        @Override
        public void handleKeyDown(KeyEvent e) {
            
        }

        @Override
        public void handleKeyUp(KeyEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            int code = e.getKeyCode();
            switch(code) {
                case KeyEvent.VK_S:
                    RRRCmdToDestroySelectionBox.execute(rrr);
                    RRRCmdToAddSelectedPtCurvesToRevisePtCurves.execute(rrr);
                    RRRCmdToChangeModeTo.execute(rrr, RRR.Mode.REVISE);

                    XCmdToChangeScene.execute(rrr, 
                        RRRReviseScenario.ReviseReadyScene.getSingleton(), 
                        null);
                    break;
            }
        }

        @Override
        public void updateSupportObjects() {
        }

        @Override
        public void renderWorldObjects(Graphics2D g2) {
        }

        @Override
        public void renderScreenObjects(Graphics2D g2) {
        }

        @Override
        public void getReady() {
        }

        @Override
        public void wrapUp() {
        }
    }
    
    public static class SelectNoteScene extends RRRScene {
        // singleton pattern
        private static SelectNoteScene mSingleton = null;
        public static SelectNoteScene createSingleton(XScenario scenario) {
            assert(SelectNoteScene.mSingleton == null);
            SelectNoteScene.mSingleton = new SelectNoteScene(scenario);
            return SelectNoteScene.mSingleton;
        }
        public static SelectNoteScene getSingleton() {
            assert(SelectNoteScene.mSingleton != null);
            return SelectNoteScene.mSingleton;
        }
        private SelectNoteScene(XScenario scenario) {
            super(scenario);
        }

        @Override
        public void handleMousePress(MouseEvent e) {
            
        }

        @Override
        public void handleMouseDrag(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            Point pt = e.getPoint();
            RRRCmdToUpdateSelectionBox.execute(rrr, pt);
            RRRCmdToUpdateSelectedRecordPtCurves.execute(rrr);
        }

        @Override
        public void handleMouseRelease(MouseEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            RRRCmdToDestroySelectionBox.execute(rrr);

            XCmdToChangeScene.execute(rrr, 
                RRRSelectScenario.SelectNoteReadyScene.getSingleton(), 
                this.mReturnScene);
        }

        @Override
        public void handleKeyDown(KeyEvent e) {
        }

        @Override
        public void handleKeyUp(KeyEvent e) {
            RRR rrr = (RRR)this.mScenario.getApp();
            int code = e.getKeyCode();
            switch(code) {
                case KeyEvent.VK_S:
                    RRRCmdToDestroySelectionBox.execute(rrr);
                    RRRCmdToAddSelectedPtCurvesToRevisePtCurves.execute(rrr);
                    RRRCmdToChangeModeTo.execute(rrr, RRR.Mode.REVISE);

                    XCmdToChangeScene.execute(rrr, 
                        RRRReviseScenario.ReviseReadyScene.getSingleton(), 
                        null);
                    break;
            }
        }

        @Override
        public void updateSupportObjects() {
        }

        @Override
        public void renderWorldObjects(Graphics2D g2) {
        }

        @Override
        public void renderScreenObjects(Graphics2D g2) {
            RRRSelectScenario scenario = (RRRSelectScenario) this.mScenario;
            scenario.drawSelectionBox(g2);
        }

        @Override
        public void getReady() {
        }

        @Override
        public void wrapUp() {
        }
    }
    
    private RRRSelectionBox mSelectionBox = null;
    public RRRSelectionBox getSelectionBox() {
        return this.mSelectionBox;
    }
    public void setSelectionBox(RRRSelectionBox selectionBox) {
        this.mSelectionBox = selectionBox;
    }
    
    private void drawSelectionBox(Graphics2D g2) {
        if(this.getSelectionBox() != null) {
            g2.setColor(RRRCanvas2D.COLOR_SELECTION_BOX);
            g2.setStroke(RRRCanvas2D.STROKE_SELECTION_BOX);
            g2.draw(this.getSelectionBox());
        }
    }
    
    public void updateSelectedPtCurves() {
        RRR rrr = (RRR)this.mApp;
        AffineTransform at = rrr.getXform().getCurXformFromScreenToWorld();
        Shape worldSelectionBoxShape = 
            at.createTransformedShape(this.mSelectionBox);
        
        ArrayList<RRRPtCurve> newlySelectedPtCurves = 
            new ArrayList<RRRPtCurve>();
        for(RRRPtCurve ptCurve : rrr.getPtCurveMgr().getPtCurves()) {
            if(worldSelectionBoxShape.intersects(ptCurve.getBoundingBox()) || 
                ptCurve.getBoundingBox().isEmpty()) {
                
                for(Point2D.Double pt : ptCurve.getPts()) {
                    if(worldSelectionBoxShape.contains(pt)) {
                        newlySelectedPtCurves.add(ptCurve);
                        break;
                    }
                }
            }
        }
        rrr.getPtCurveMgr().getPtCurves().removeAll(newlySelectedPtCurves);
        rrr.getPtCurveMgr().getSelectedPtCurves().addAll(newlySelectedPtCurves);
    }
    
    public void updateSelectedRecordPtCurves() {
        RRR rrr = (RRR)this.mApp;
        AffineTransform at = rrr.getXform().getCurXformFromScreenToWorld();
        Shape worldSelectionBoxShape = 
            at.createTransformedShape(this.mSelectionBox);
        
        ArrayList<RRRPtCurve> newlySelectedPtCurves = 
            new ArrayList<RRRPtCurve>();
        for(RRRPtCurve ptCurve : rrr.getPtCurveMgr().getRecordPtCurves()) {
            if(worldSelectionBoxShape.intersects(ptCurve.getBoundingBox()) || 
                ptCurve.getBoundingBox().isEmpty()) {
                
                for(Point2D.Double pt : ptCurve.getPts()) {
                    if(worldSelectionBoxShape.contains(pt)) {
                        newlySelectedPtCurves.add(ptCurve);
                        break;
                    }
                }
            }
        }
        rrr.getPtCurveMgr().getRecordPtCurves().removeAll(newlySelectedPtCurves);
        rrr.getPtCurveMgr().getSelectedPtCurves().addAll(newlySelectedPtCurves);
    }
}
