package rrr;

import java.awt.Point;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class RRRPenMarkMgr {
    // constants
    private static final int MAX_NUM_PEN_MARKS = 10;
    
    // fields
    private ArrayList<RRRPenMark> mPenMarks = null;
    public ArrayList<RRRPenMark> getPenMarks() {
        return this.mPenMarks;
    }
    
    // constructor
    public RRRPenMarkMgr() {
        this.mPenMarks = new ArrayList<RRRPenMark>();
    }
    
    // methods
    public void addPenMark(RRRPenMark penMark) {
        this.mPenMarks.add(penMark);
        if(this.mPenMarks.size() > RRRPenMarkMgr.MAX_NUM_PEN_MARKS) {
            this.mPenMarks.remove(0);
            assert(this.mPenMarks.size() <= RRRPenMarkMgr.MAX_NUM_PEN_MARKS);
        }
    }
    
    public RRRPenMark getlastPenMark() {
        int size = this.mPenMarks.size();
        if(size == 0) {
            return null;
        } else {
            return this.mPenMarks.get(size - 1);
        }
    }
    
    public RRRPenMark getRecentPenMark(int i) {
        int size = this.mPenMarks.size();
        int index = size - 1 - i;
        if(index < 0 || index >= size) {
            return null;
        } else {
            return this.mPenMarks.get(index);
        }
    }
    
    public boolean handleMousePress(MouseEvent e) {
        Point pt = e.getPoint();
        RRRPenMark penMark = new RRRPenMark(pt);
        this.addPenMark(penMark);
        return true;
    }
    
    public boolean handleMouseDrag(MouseEvent e) {
        Point pt = e.getPoint();
        RRRPenMark penMark = this.getlastPenMark();
        if(penMark != null) {
            penMark.addPt(pt);
            return true;
        } else {
            return false;
        }
    }
    
    public boolean handleMouseRelease(MouseEvent e) {
        return true;
    }
}
