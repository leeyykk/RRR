package rrr;

import java.awt.Point;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

public class RRRUnderline extends Line2D {
    // fields
    private Point mStartPt = null;
    public Point getStartPt() {
        return this.mStartPt;
    }
    private Point mEndPt = null;
    
    // constructor
    public RRRUnderline(Point pt) {
        this.mStartPt = pt;
        this.mEndPt = pt;
    }
    
    // methods
    public void update(Point pt) {
        this.mEndPt = new Point(pt.x, this.mStartPt.y);
        
    }

    @Override
    public double getX1() {
        return this.mStartPt.x;
    }

    @Override
    public double getY1() {
        return this.mStartPt.y;
    }

    @Override
    public Point2D getP1() {
        return this.mStartPt;
    }

    @Override
    public double getX2() {
        return this.mEndPt.x;
    }

    @Override
    public double getY2() {
        return this.mEndPt.y;
    }

    @Override
    public Point2D getP2() {
        return this.mEndPt;
    }

    @Override
    public void setLine(double x1, double y1, double x2, double y2) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Rectangle2D getBounds2D() {
        Rectangle2D boundingBox = new Rectangle2D.Double(this.mStartPt.x, 
            this.mStartPt.y - RRRGraphObject.BOUNDING_BOX_HEIGHT, 
            this.mEndPt.x - this.mStartPt.x, 
            RRRGraphObject.BOUNDING_BOX_HEIGHT);
        return boundingBox;
    }
}
