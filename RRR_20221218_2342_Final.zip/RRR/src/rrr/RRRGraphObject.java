package rrr;

import java.awt.Shape;
import java.awt.image.BufferedImage;

public abstract class RRRGraphObject implements Shape {
    // constants
    public static final int BOUNDING_BOX_HEIGHT = 32;
    
    // fields
    private BufferedImage mImage = null;
    public BufferedImage getImage() {
        return this.mImage;
    }
    public void setImage(BufferedImage image) {
        this.mImage = image;
    }
    
    private boolean mIsHighlighted = false;
    public boolean getIsHighlighted() {
        return this.mIsHighlighted;
    }
    public void setIsHighlighted(boolean isSelected) {
        this.mIsHighlighted = isSelected;
    }
    
    // constructor
    public RRRGraphObject(BufferedImage image) {
        this.mImage = image;
    }
}
