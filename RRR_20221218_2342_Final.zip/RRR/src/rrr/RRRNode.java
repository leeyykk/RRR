package rrr;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class RRRNode extends RRRGraphObject {
    // fields
    private Point mCenter = null;
    public Point getCenter() {
        return this.mCenter;
    }
    public void setCenter(Point center) {
        this.mCenter = center;
    }
    
    private int mNodeDiameter = 0;
    public int getNodeDiameter() {
        return this.mNodeDiameter;
    }
    
    private ArrayList<RRREdge> mStartEdgeList  = null;
    public ArrayList<RRREdge> getStartEdgeList() {
        return this.mStartEdgeList;
    }
    private ArrayList<RRREdge> mEndEdgeList  = null;
    public ArrayList<RRREdge> getEndEdgeList() {
        return this.mEndEdgeList;
    }
    
    // constructor
    public RRRNode(Point pt, BufferedImage image) {
        super(image);
        
        this.mCenter = new Point(pt.x + image.getWidth() / 2, 
            pt.y - image.getHeight() / 2);
        this.mNodeDiameter = image.getWidth()+5;
                
        this.mStartEdgeList = new ArrayList<RRREdge>();
        this.mEndEdgeList = new ArrayList<RRREdge>();
    }
    
    // methods 
    @Override
    public Rectangle getBounds() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Rectangle2D getBounds2D() {
        Rectangle2D boundingBox = new Rectangle2D.Double(
            this.mCenter.x - this.mNodeDiameter / 2, 
            this.mCenter.y - this.mNodeDiameter / 2, 
            this.mNodeDiameter, this.mNodeDiameter);
        return boundingBox;
    }

    @Override
    public boolean contains(double x, double y) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean contains(Point2D p) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean intersects(double x, double y, double w, double h) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean intersects(Rectangle2D r) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean contains(double x, double y, double w, double h) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean contains(Rectangle2D r) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public PathIterator getPathIterator(AffineTransform at) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public PathIterator getPathIterator(AffineTransform at, double flatness) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
