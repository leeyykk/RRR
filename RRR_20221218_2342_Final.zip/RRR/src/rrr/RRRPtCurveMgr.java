package rrr;


import java.util.ArrayList;
import rrr.RRR.Mode;

public class RRRPtCurveMgr {
    // fields
    private RRR mRRR = null;
    
    private RRRPtCurve mCurPtCurve = null;
    public RRRPtCurve getCurPtCurve() {
        return this.mCurPtCurve;
    }
    public void setCurPtCurve(RRRPtCurve ptCurve) {
        this.mCurPtCurve = ptCurve;
    }

    private ArrayList<RRRPtCurve> mReviewPtCurves = null;
    private ArrayList<RRRPtCurve> mRecordPtCurves = null;
    public ArrayList<RRRPtCurve> getRecordPtCurves() {
        return this.mRecordPtCurves;
    }
    private ArrayList<RRRPtCurve> mRevisePtCurves = null;
    public ArrayList<RRRPtCurve> getRevisePtCurves() {
        return this.mRevisePtCurves;
    }

    private ArrayList<RRRPtCurve> mPtCurves = null;
    public ArrayList<RRRPtCurve> getPtCurves() {
        Mode mode = this.mRRR.getMode();
        switch(mode) {
            case REVIEW:
                this.mPtCurves = this.mReviewPtCurves;
                break;
            case QUESTION:
                this.mPtCurves = this.mQuestionPtCurves;
                break;
            case RECORD:
                this.mPtCurves = this.mRecordPtCurves;
                break;
            case REVISE:
                this.mPtCurves = this.mRevisePtCurves;
                break;
        }
        return this.mPtCurves;
    }
    
    private ArrayList<RRRPtCurve> mSelectedPtCurves = null;
    public ArrayList<RRRPtCurve> getSelectedPtCurves() {
        return this.mSelectedPtCurves;
    }
    
    private ArrayList<RRRPtCurve> mQuestionPtCurves = null;
    public ArrayList<RRRPtCurve> getQuestionPtCurves() {
        return this.mQuestionPtCurves;
    }
    
    private boolean mRecordPtCurvesVisibility = false;
    public boolean getRecordPtCurvesVisibility() {
        return this.mRecordPtCurvesVisibility;
    }
    
    // constructor
    public RRRPtCurveMgr(RRR rrr) {
        this.mRRR = rrr;
        
        // create a pen mark array
        this.mReviewPtCurves = new ArrayList<RRRPtCurve>();
        this.mRecordPtCurves = new ArrayList<RRRPtCurve>();
        this.mRevisePtCurves = new ArrayList<RRRPtCurve>();
        
        // create a selected pen mark array
        this.mSelectedPtCurves = new ArrayList<RRRPtCurve>();

        // create a question list pen mark array
        this.mQuestionPtCurves = new ArrayList<RRRPtCurve>();
    }
    
    // methods
    public void addToRevisePtCurves(RRRPtCurve ptCurve) {
        this.mRevisePtCurves.add(ptCurve);
    }
    
    public void deleteLastQuestionPtCurves() {
        this.mQuestionPtCurves.remove(this.mQuestionPtCurves.size()-1);
    }
    
    public void toggleRecordPtCurvesVisibility() {
        this.mRecordPtCurvesVisibility = !this.mRecordPtCurvesVisibility;
    }
}
