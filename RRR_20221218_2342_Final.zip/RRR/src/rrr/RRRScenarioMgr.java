package rrr;

import rrr.scenario.RRRDefaultScenario;
import rrr.scenario.RRRDrawScenario;
import rrr.scenario.RRRNavigateScenario;
import rrr.scenario.RRRReviewScenario;
import rrr.scenario.RRRSelectScenario;
import rrr.scenario.RRRRecordScenario;
import rrr.scenario.RRRReviseScenario;
import x.XScenarioMgr;

public class RRRScenarioMgr extends XScenarioMgr {
    // constructor
    public RRRScenarioMgr(RRR rrr) {
        super(rrr);
    }
    
    // methods
    @Override
    protected void addScenarios() {
        this.addScenario(RRRDefaultScenario.createSingleton(this.mApp));
        this.addScenario(RRRReviewScenario.createSingleton(this.mApp));
        this.addScenario(RRRRecordScenario.createSingleton(this.mApp));
        this.addScenario(RRRReviseScenario.createSingleton(this.mApp));
        this.addScenario(RRRDrawScenario.createSingleton(this.mApp));
        this.addScenario(RRRSelectScenario.createSingleton(this.mApp));
        this.addScenario(RRRNavigateScenario.createSingleton(this.mApp));
    }

    @Override
    protected void setInitCurScene() {
        this.setCurScene(RRRDefaultScenario.ReadyScene.getSingleton());
    }
}
