package rrr;

import java.awt.Point;
import java.awt.geom.AffineTransform;
import java.awt.geom.NoninvertibleTransformException;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

public class RRRXform {
    // constants
    public static final Point PIVOT_PT = new Point(0, 0);
    public static final double MIN_START_ARM_LENGTH_FOR_SCALING = 100.0;
    
    // fields
    private RRR mRRR = null;
    
    private AffineTransform mCurXformFromWorldToScreen = null;
    public AffineTransform getCurXformFromWorldToScreen() {
        return this.mCurXformFromWorldToScreen;
    }
    private AffineTransform mCurXformFromScreenToWorld = null;
    public AffineTransform getCurXformFromScreenToWorld() {
        return this.mCurXformFromScreenToWorld;
    }
    private AffineTransform mStartXformFromWorldToScreen = null;
    private Point mStartScreenPt = null;
    public void setStartScreenPt(Point pt) {
        this.mStartScreenPt = pt;
        this.mStartXformFromWorldToScreen.setTransform(
            this.mCurXformFromWorldToScreen);
    }
    
    // constructor
    public RRRXform(RRR rrr) {
        this.mRRR = rrr;
        
        this.mCurXformFromWorldToScreen = new AffineTransform();
        this.mCurXformFromScreenToWorld = new AffineTransform();
        this.mStartXformFromWorldToScreen = new AffineTransform();
    }
    
    // methods
    
    // call whenever mCurXformFromWorldToScreen changes to have 
    // its corresponding mCurXformFromScreenToWorld
    public void updateCurXformFromScreenToWorld() {
        try {
            this.mCurXformFromScreenToWorld = 
                this.mCurXformFromWorldToScreen.createInverse();
        } catch(NoninvertibleTransformException ex) {
            System.out.println("NoninvertibleTransformException");
        }
    }
    
    public Point calcPtFromWorldToScreen(Point2D.Double worldPt) {
        Point screenPt = new Point();
        this.mCurXformFromWorldToScreen.transform(worldPt, screenPt);
        return screenPt;
    }
    
    public Point2D.Double calcPtFromScreenToWorld(Point screenPt) {
        Point2D.Double worldPt = new Point2D.Double();
        this.mCurXformFromScreenToWorld.transform(screenPt, worldPt);
        return worldPt;
    }
    
    public boolean translateTo(Point pt) {
        if(this.mStartScreenPt == null) {
            return false;
        }
        
        ArrayList<RRRPtCurve> ptCurves = this.mRRR.getPtCurveMgr().
            getSelectedPtCurves();
        if(ptCurves != null) {
            double dx = pt.x - this.mStartScreenPt.x;
            double dy = pt.y - this.mStartScreenPt.y;
            for(RRRPtCurve ptCurve : ptCurves) {
                ArrayList<Point2D.Double> pts = ptCurve.getPts();
                Rectangle2D.Double boundingBox = new Rectangle2D.Double();
                for(int i = 0; i < pts.size(); i++) {
                    Point2D.Double newPt = new Point2D.Double(
                        pts.get(i).x + dx, pts.get(i).y + dy);
                    pts.set(i, newPt);
                    boundingBox.add(newPt);
                }
                ptCurve.setBoundingBox(boundingBox);
            }
        }
        
        this.mStartScreenPt = pt;
        
        return true;
    }

    public boolean zoomRotateTo(Point pt) {
        if(this.mStartScreenPt == null) {
            return false;
        }
        
        double d0 = RRRXform.PIVOT_PT.distance(this.mStartScreenPt);
        double d1 = RRRXform.PIVOT_PT.distance(pt);
        if(d0 < RRRXform.MIN_START_ARM_LENGTH_FOR_SCALING) {
            return false;
        }
        double s = d1 / d0;
        
        double ang0 = StrictMath.atan2(
            this.mStartScreenPt.y - RRRXform.PIVOT_PT.y,
            this.mStartScreenPt.x - RRRXform.PIVOT_PT.x);
        double ang1 = StrictMath.atan2(
            pt.y - RRRXform.PIVOT_PT.y,
            pt.x - RRRXform.PIVOT_PT.x);
        double ang = ang1 - ang0;
        double cosA = StrictMath.cos(ang);
        double sinA = StrictMath.sin(ang);
        
        ArrayList<RRRPtCurve> ptCurves = this.mRRR.getPtCurveMgr().
            getSelectedPtCurves();
        if(ptCurves != null) {
            for(RRRPtCurve ptCurve: ptCurves) {
                ArrayList<Point2D.Double> pts = ptCurve.getPts();
                Rectangle2D.Double boundingBox = new Rectangle2D.Double();
                for(int i = 0; i < pts.size(); i++) {
                    double r = RRRXform.PIVOT_PT.distance(pts.get(i));
                    double cosB = (pts.get(i).x - RRRXform.PIVOT_PT.x) / r;
                    double sinB = (pts.get(i).y - RRRXform.PIVOT_PT.y) / r;
                    Point2D.Double newPt = new Point2D.Double(
                        RRRXform.PIVOT_PT.x + 
                            r * s * (cosA * cosB - sinA * sinB),
                        RRRXform.PIVOT_PT.y + 
                            r * s * (sinA * cosB + cosA * sinB));
                    pts.set(i, newPt);
                    boundingBox.add(newPt);
                }
                ptCurve.setBoundingBox(boundingBox);
            }
        }
        
        this.mStartScreenPt = pt;
        
        return true;
    }
}
