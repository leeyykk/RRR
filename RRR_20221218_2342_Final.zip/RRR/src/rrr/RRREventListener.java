package rrr;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public class RRREventListener implements MouseListener, MouseMotionListener, 
    KeyListener {
    
    // fields
    private RRR mRRR = null;
    
    // constructor
    public RRREventListener(RRR rrr) {
        this.mRRR = rrr;
    }

    // methods
    @Override
    public void mousePressed(MouseEvent e) {
        if(this.mRRR.getPenMarkMgr().handleMousePress(e)) {
            RRRScene curScene = 
                (RRRScene)this.mRRR.getScenarioMgr().getCurScene();
            curScene.handleMousePress(e);
            this.mRRR.repaint();
        }
    }
    
    @Override
    public void mouseDragged(MouseEvent e) {
        if(this.mRRR.getPenMarkMgr().handleMouseDrag(e)) {
            RRRScene curScene = 
                (RRRScene)this.mRRR.getScenarioMgr().getCurScene();
            curScene.handleMouseDrag(e);
            this.mRRR.repaint();
        }
    }
    
    @Override
    public void mouseReleased(MouseEvent e) {
        if(this.mRRR.getPenMarkMgr().handleMouseRelease(e)) {
            RRRScene curScene = 
                (RRRScene)this.mRRR.getScenarioMgr().getCurScene();
            curScene.handleMouseRelease(e);
            this.mRRR.repaint();
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }
    
    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseMoved(MouseEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
        RRRScene curScene = (RRRScene)this.mRRR.getScenarioMgr().getCurScene();
        curScene.handleKeyDown(e);
        this.mRRR.repaint();
    }

    @Override
    public void keyReleased(KeyEvent e) {
        RRRScene curScene = (RRRScene)this.mRRR.getScenarioMgr().getCurScene();
        curScene.handleKeyUp(e);
        this.mRRR.repaint();
    }
    
    @Override
    public void keyTyped(KeyEvent e) {
    }
}
