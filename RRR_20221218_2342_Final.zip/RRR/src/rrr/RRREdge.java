package rrr;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;

public class RRREdge extends RRRGraphObject {    
    // fields
    private Point mStartPt = null;
    public Point getStartPt() {
        return this.mStartPt;
    }
    public void setStartPt(Point pt) {
        this.mStartPt = pt;
    }
    private Point mEndPt = null;
    public Point getEndPt() {
        return this.mEndPt;
    }
    public void setEndPt(Point pt) {
        this.mEndPt = pt;
    }
    
    private RRRNode mFirstNode  = null;
    public RRRNode getFirstNode() {
        return this.mFirstNode;
    }
    public void setFirstNode(RRRNode node) {
        this.mFirstNode = node;
        if(node != null) {
            this.mStartPt = node.getCenter();
        } else {
            this.mStartPt = new Point(
                (this.mStartPt.x + this.mEndPt.x) / 2, 
                (this.mStartPt.y + this.mEndPt.y) / 2);
        }
    }
    private RRRNode mSecondNode  = null;
    public RRRNode getSecondNode() {
        return this.mSecondNode;
    }
    public void setSecondNode(RRRNode node) {
        this.mSecondNode = node;
        if(node != null) {
            this.mEndPt = node.getCenter();
        } else {
            this.mEndPt = new Point(
                (this.mStartPt.x + this.mEndPt.x) / 2, 
                (this.mStartPt.y + this.mEndPt.y) / 2);
        }
    }
    
    // constructor
    public RRREdge(Point startPt, Point endPt, BufferedImage image) {
        super(image);
        this.mStartPt = startPt;
        this.mEndPt = endPt;
    }
    
    // methods
    @Override
    public Rectangle getBounds() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Rectangle2D getBounds2D() {
        double centerX = (this.mStartPt.x + this.mEndPt.x) / 2;
        double centerY = (this.mStartPt.y + this.mEndPt.y) / 2;
        double width = this.getImage().getWidth();
        double height = this.getImage().getHeight();
        Rectangle2D boundingBox = new Rectangle2D.Double(
            centerX - width / 2, centerY - height / 2, width, height);
        return boundingBox;
    }

    @Override
    public boolean contains(double x, double y) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean contains(Point2D p) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean intersects(double x, double y, double w, double h) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean intersects(Rectangle2D r) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean contains(double x, double y, double w, double h) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public boolean contains(Rectangle2D r) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public PathIterator getPathIterator(AffineTransform at) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public PathIterator getPathIterator(AffineTransform at, double flatness) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
