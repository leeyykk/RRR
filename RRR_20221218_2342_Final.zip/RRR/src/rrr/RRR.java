package rrr;

import javax.swing.JFrame;
import javax.swing.JPanel;
import rrr.cmd.RRRCmdToDeselectSelectedPtCurves;
import x.XApp;
import x.XLogMgr;
import x.XScenarioMgr;

public class RRR extends XApp {
    // modes
    public enum Mode { NONE, REVIEW, QUESTION, RECORD, REVISE, 
        EXTRACTNODE, EXTRACTEDGE };
    
    // constants
    public static final int APP_WIDTH = 1670;
    public static final int APP_HEIGHT = 990;
    public static final int HEADER_HEIGHT = 50;
    
    // fields
    private Mode mMode = Mode.NONE;
    public Mode getMode() {
        return this.mMode;
    }
    public void setMode(Mode mode) {
        if(this.mMode != Mode.NONE) {
            RRRCmdToDeselectSelectedPtCurves.execute(this);
        }
        this.mMode = mode;
    }
    
    private JFrame mFrame = null;
    private JPanel mHeader = null;
    
    private RRRCanvas2D mCanvas2D = null;
    public RRRCanvas2D getCanvas2D() {
        return this.mCanvas2D;
    }
    
    private RRRXform mXform = null;
    public RRRXform getXform() {
        return this.mXform;
    }
    
    private RRREventListener mEventListener = null;
    
    private RRRPenMarkMgr mPenMarkMgr = null;
    public RRRPenMarkMgr getPenMarkMgr() {
        return this.mPenMarkMgr;
    }
    
    private RRRPtCurveMgr mPtCurveMgr = null;
    public RRRPtCurveMgr getPtCurveMgr() {
        return this.mPtCurveMgr;
    }
    
    private XScenarioMgr mScenarioMgr = null;
    @Override
    public XScenarioMgr getScenarioMgr() {
        return this.mScenarioMgr;
    }

    private XLogMgr mLogMgr = null;
    @Override
    public XLogMgr getLogMgr() {
        return this.mLogMgr;
    }
    
    // constructor
    public RRR() {
        // create components
        // 1) frame, 2) header and canvas, 3) other components,
        // 4) event listeners, 5) managers
        this.mFrame = new JFrame("RRR");
        this.mHeader = new RRRHeader(this);
        this.mCanvas2D = new RRRCanvas2D(this);
        this.mXform = new RRRXform(this);
        this.mEventListener = new RRREventListener(this);
        this.mPenMarkMgr = new RRRPenMarkMgr();
        this.mPtCurveMgr = new RRRPtCurveMgr(this);
        this.mScenarioMgr = new RRRScenarioMgr(this);
        this.mLogMgr = new XLogMgr();
        this.mLogMgr.setPrintOn(true);
        
        // connect event listeners
        this.mCanvas2D.addMouseListener(this.mEventListener);
        this.mCanvas2D.addMouseMotionListener(this.mEventListener);
        
        this.mHeader.setFocusable(false);
        this.mFrame.setFocusable(true);
        this.mFrame.addKeyListener(this.mEventListener);
        
        // build and show visual components
        this.mFrame.setSize(RRR.APP_WIDTH, RRR.APP_HEIGHT);
        this.mFrame.setLayout(null);
        this.mHeader.setBounds(0, 0, RRR.APP_WIDTH, RRR.HEADER_HEIGHT);
        this.mCanvas2D.setBounds(0, RRR.HEADER_HEIGHT, RRR.APP_WIDTH, 
            RRR.APP_HEIGHT - RRR.HEADER_HEIGHT);
        this.mFrame.getContentPane().add(this.mHeader);
        this.mFrame.getContentPane().add(this.mCanvas2D);
        this.mFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.mFrame.setVisible(true);
    }
    
    // methods
    public static void main(String[] args) {
        new RRR();  // create a RRR instance
    }
    
    public void repaint() {
        this.mPtCurveMgr.getPtCurves();
        this.mHeader.repaint();
        this.mCanvas2D.repaint();
    }
}