package x;

public interface XExecutable {
    public abstract boolean execute();
}
